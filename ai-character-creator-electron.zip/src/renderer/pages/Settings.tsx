import {
  AlertTriangle,
  CheckCircle2,
  Loader2,
  RefreshCw,
  Sparkles,
  ShieldAlert,
  ShieldCheck,
  Terminal,
} from "lucide-react";
import { CopyButton } from "@/components/copy-button";
import { useClaudeStatus } from "@/hooks/use-claude-status";
import { useSettings } from "@/hooks/use-settings";
import {
  DEFAULT_GENERATION_MODEL,
  GENERATION_MODELS,
  GENERATION_MODEL_META,
  type GenerationModel,
} from "@shared/schemas";

const INSTALL_COMMAND = "npm install -g @anthropic-ai/claude-code";
const LOGIN_COMMAND = "claude login";

export function SettingsPage() {
  const { settings, loading, update } = useSettings();
  const claude = useClaudeStatus();

  const superAdmin = settings?.superAdmin ?? false;
  const generationModel: GenerationModel =
    settings?.generationModel ?? DEFAULT_GENERATION_MODEL;

  return (
    <div className="mx-auto max-w-2xl px-4 py-10 sm:px-6">
      <div className="mb-8 flex items-center gap-3">
        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/15">
          <ShieldCheck className="h-4 w-4 text-primary" />
        </div>
        <div>
          <h1 className="font-semibold text-lg tracking-tight">Settings</h1>
          <p className="text-muted-foreground text-xs">Application configuration</p>
        </div>
      </div>

      <div className="space-y-4">
        <ClaudeStatusCard
          status={claude.status}
          version={claude.version}
          error={claude.error}
          onRecheck={() => void claude.recheck()}
        />

        <div className="rounded-xl border border-white/8 bg-white/2 p-5">
          <div className="flex items-start gap-3">
            <div className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-primary/15 text-primary">
              <Sparkles className="h-4 w-4" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="font-medium text-sm">Generation model</p>
              <p className="mt-1 text-muted-foreground text-xs leading-relaxed">
                The Claude model used for character generation, scene prompts, and the
                gathering chat. Opus delivers the highest quality; Sonnet is faster and
                cheaper.
              </p>
              <div className="mt-3 grid gap-2 sm:grid-cols-2">
                {GENERATION_MODELS.map((model) => {
                  const meta = GENERATION_MODEL_META[model];
                  const active = generationModel === model;
                  return (
                    <button
                      key={model}
                      aria-pressed={active}
                      className={`group relative rounded-lg border px-3 py-2.5 text-left transition-colors ${
                        active
                          ? "border-primary/60 bg-primary/10"
                          : "border-white/8 bg-white/2 hover:border-white/15 hover:bg-white/5"
                      } ${loading ? "cursor-wait opacity-60" : "cursor-pointer"}`}
                      disabled={loading || active}
                      onClick={() => void update({ generationModel: model })}
                      type="button"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span
                          className={`font-medium text-sm ${
                            active ? "text-foreground" : "text-foreground/90"
                          }`}
                        >
                          {meta.label}
                        </span>
                        {active && (
                          <span className="rounded-full bg-primary/20 px-1.5 py-0.5 font-medium text-[10px] text-primary uppercase tracking-wide">
                            Active
                          </span>
                        )}
                      </div>
                      <p className="mt-1 text-muted-foreground text-[11px] leading-relaxed">
                        {meta.description}
                      </p>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        <div
          className={`rounded-xl border p-5 transition-colors ${
            superAdmin ? "border-amber-500/40 bg-amber-500/5" : "border-white/8 bg-white/2"
          }`}
        >
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-start gap-3">
              <div
                className={`mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg ${
                  superAdmin ? "bg-amber-500/20 text-amber-400" : "bg-white/5 text-muted-foreground"
                }`}
              >
                <ShieldAlert className="h-4 w-4" />
              </div>
              <div>
                <p className="font-medium text-sm">Super Admin Mode</p>
                <p className="mt-1 text-muted-foreground text-xs leading-relaxed">
                  Overrides AI-agent refusals based on character consistency
                  ("this scene does not fit the character's personality", "out of character",
                  etc.). The operator's creative intent takes precedence over the agent's self-judgment.
                  <br />
                  <span className="mt-1 inline-block font-medium text-foreground/70">
                    Absolute legal limits still apply (no content involving minors).
                  </span>
                </p>
              </div>
            </div>
            <button
              aria-label="Toggle super administrator"
              className={`relative inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors ${
                superAdmin ? "bg-amber-500/80" : "bg-white/10"
              } ${loading ? "cursor-wait opacity-60" : "cursor-pointer"}`}
              disabled={loading}
              onClick={() => void update({ superAdmin: !superAdmin })}
              type="button"
            >
              <span
                className={`inline-block h-5 w-5 transform rounded-full bg-white shadow-lg transition-transform ${
                  superAdmin ? "translate-x-5" : "translate-x-0.5"
                }`}
              />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function ClaudeStatusCard({
  status,
  version,
  error,
  onRecheck,
}: {
  status: "checking" | "connected" | "disconnected";
  version?: string;
  error?: string;
  onRecheck: () => void;
}) {
  const tone =
    status === "connected"
      ? "border-emerald-500/30 bg-emerald-500/5"
      : status === "disconnected"
        ? "border-red-500/30 bg-red-500/5"
        : "border-white/8 bg-white/2";

  return (
    <div className={`rounded-xl border p-5 transition-colors ${tone}`}>
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-start gap-3">
          <div
            className={`mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg ${
              status === "connected"
                ? "bg-emerald-500/20 text-emerald-400"
                : status === "disconnected"
                  ? "bg-red-500/20 text-red-400"
                  : "bg-white/5 text-muted-foreground"
            }`}
          >
            {status === "connected" && <CheckCircle2 className="h-4 w-4" />}
            {status === "disconnected" && <AlertTriangle className="h-4 w-4" />}
            {status === "checking" && <Loader2 className="h-4 w-4 animate-spin" />}
          </div>
          <div className="min-w-0">
            <p className="font-medium text-sm">Claude Code connection</p>
            {status === "connected" && (
              <p className="mt-1 text-muted-foreground text-xs leading-relaxed">
                Connected and ready for generation.
                {version && (
                  <>
                    {" "}
                    <span className="font-mono text-emerald-400/80">{version}</span>
                  </>
                )}
              </p>
            )}
            {status === "checking" && (
              <p className="mt-1 text-muted-foreground text-xs leading-relaxed">
                Checking the Claude Code CLI…
              </p>
            )}
            {status === "disconnected" && (
              <p className="mt-1 text-muted-foreground text-xs leading-relaxed">
                The Claude Code CLI is not available or not authenticated. Character
                generation won't work until this is fixed.
                {error && (
                  <span className="mt-1 block font-mono text-[11px] text-red-300/80">
                    {error}
                  </span>
                )}
              </p>
            )}
          </div>
        </div>
        <button
          className="inline-flex items-center gap-1.5 rounded-md border border-white/10 bg-white/5 px-2.5 py-1 font-medium text-xs transition hover:bg-white/10"
          onClick={onRecheck}
          type="button"
        >
          <RefreshCw className="h-3 w-3" />
          Re-check
        </button>
      </div>

      {status === "disconnected" && (
        <div className="mt-4 space-y-3 border-white/5 border-t pt-4">
          <p className="flex items-center gap-2 font-medium text-xs">
            <Terminal className="h-3.5 w-3.5 text-muted-foreground" />
            How to fix — run these in a terminal
          </p>
          <CommandRow label="1. Install the Claude Code CLI" command={INSTALL_COMMAND} />
          <CommandRow label="2. Authenticate your account" command={LOGIN_COMMAND} />
          <p className="text-muted-foreground text-[11px] leading-relaxed">
            Once both commands succeed, click <strong>Re-check</strong> above.
          </p>
        </div>
      )}
    </div>
  );
}

function CommandRow({ label, command }: { label: string; command: string }) {
  return (
    <div>
      <p className="mb-1 text-muted-foreground text-[11px]">{label}</p>
      <div className="flex items-center gap-2 rounded-md border border-white/10 bg-black/40 px-3 py-2">
        <code className="flex-1 select-all overflow-x-auto font-mono text-xs text-foreground/90">
          {command}
        </code>
        <CopyButton value={command} />
      </div>
    </div>
  );
}
