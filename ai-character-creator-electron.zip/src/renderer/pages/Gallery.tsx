import { Plus, Sparkles, Wand2 } from "lucide-react";
import { useEffect, useState } from "react";
import { CharacterCard } from "@/components/character-card";
import { Button } from "@/components/ui/button";
import type { StoredCharacter } from "@/lib/types";

export function GalleryPage() {
  const [characters, setCharacters] = useState<StoredCharacter[]>([]);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    window.api.characters.list().then((list) => {
      setCharacters(list);
      setLoaded(true);
    });
  }, []);

  if (!loaded) {
    return (
      <div className="flex flex-1 min-h-0 items-center justify-center">
        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10">
          <Sparkles className="h-4 w-4 animate-pulse text-primary" />
        </div>
      </div>
    );
  }

  if (characters.length === 0) {
    return (
      <div className="flex min-h-0 flex-1 flex-col items-center gap-8 px-4 pt-32 pb-12">
        <div className="flex flex-col items-center text-center">
          <div className="glow-md mb-6 flex h-20 w-20 items-center justify-center rounded-3xl bg-primary/10">
            <Wand2 className="h-9 w-9 text-primary" />
          </div>
          <h2 className="mb-3 font-semibold text-2xl tracking-tight">No characters yet</h2>
          <p className="max-w-sm text-muted-foreground leading-relaxed">
            Create your first AI character by describing a concept. The AI will guide you through
            the process with interactive questions.
          </p>
        </div>
        <a href="#/create">
          <Button className="glow-sm" size="lg">
            <Plus className="mr-2 h-4 w-4" />
            Create Character
          </Button>
        </a>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <div className="mb-8 flex items-end justify-between">
        <div>
          <h1 className="font-semibold text-2xl tracking-tight">Character Gallery</h1>
          <p className="mt-1 text-muted-foreground text-sm">
            {characters.length} character{characters.length === 1 ? "" : "s"} created
          </p>
        </div>
        <a href="#/create">
          <Button className="glow-sm">
            <Plus className="mr-2 h-4 w-4" />
            Create Character
          </Button>
        </a>
      </div>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {characters.map((c) => (
          <CharacterCard data={c} key={c.id} />
        ))}
      </div>
    </div>
  );
}
