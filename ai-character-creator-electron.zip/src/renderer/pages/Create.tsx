import { Bot, Check, RotateCcw, Sparkles, Wand2 } from "lucide-react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { ChatContainer } from "@/components/chat/chat-container";
import { ChatMessage } from "@/components/chat/chat-message";
import { AutopilotPill } from "@/components/chrome/autopilot-pill";
import { ChatDock } from "@/components/chrome/chat-dock";
import { ChatDockSlot, SubHeaderSlot } from "@/components/chrome/chrome-slots";
import { DifficultyPill } from "@/components/chrome/difficulty-pill";
import { ImageModelPill } from "@/components/chrome/image-model-pill";
import { MessageLengthPill } from "@/components/chrome/message-length-pill";
import { SceneCountPill } from "@/components/chrome/scene-count-pill";
import { Stepper } from "@/components/chrome/stepper";
import { SubHeader } from "@/components/chrome/sub-header";
import { useChatAutopilot } from "@/hooks/use-chat-autopilot";
import { GenerationSteps, type StepState } from "@/components/create/generation-steps";
import { ProfileReview } from "@/components/profile-review";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useAgentChat } from "@/hooks/use-agent-chat";
import { useSettings } from "@/hooks/use-settings";
import { navigate } from "@/lib/router";
import {
  CHARACTER_STEP_IDS,
  type Character,
  type CharacterProfilePreview,
  type CharacterStepId,
  clampSceneCount,
  type ConfirmedProfile,
  DEFAULT_IMAGE_MODEL,
  DEFAULT_MESSAGE_LENGTH,
  DEFAULT_SCENE_COUNT,
  type Difficulty,
  getFullName,
  type ImageModel,
  type Measurements,
  type MessageLength,
} from "@/lib/types";
import { serializeTranscriptForReplay } from "@shared/chat-replay";
import type { GenerateProgressEvent, GenerateStepId } from "@shared/generate";

type Phase =
  | "character-gathering"
  | "character-profile-review"
  | "character-generating"
  | "scene-gathering"
  | "scene-generating"
  | "done";

const CHARACTER_STEP_LABELS: Record<CharacterStepId, string> = {
  light: "Identity, greeting, difficulty/intimacy profiles",
  scenario: "Scenario (narrative, intimacy, trust system)",
  personality: "Detailed personality (XML sections)",
  extras: "Lore, backstory, NPCs",
  visual: "Physical description and visual prompts",
};

const STEPPER_STEPS = [
  { id: "character", label: "Character" },
  { id: "scenes", label: "Scenes" },
];

function initialCharacterSteps(): StepState[] {
  return CHARACTER_STEP_IDS.map((id) => ({
    id: id as GenerateStepId,
    label: CHARACTER_STEP_LABELS[id],
    status: "idle",
  }));
}

function initialSceneSteps(count: number): StepState[] {
  return [{ id: "scenes", label: `Generating ${count} scenes`, status: "idle" }];
}

const summarizeChat = serializeTranscriptForReplay;

export function CreatePage() {
  const [phase, setPhase] = useState<Phase>("character-gathering");
  const [difficulty, setDifficulty] = useState<Difficulty>("medium");
  const [messageLength, setMessageLength] = useState<MessageLength>(DEFAULT_MESSAGE_LENGTH);
  const [imageModel, setImageModel] = useState<ImageModel>(DEFAULT_IMAGE_MODEL);
  const [sceneCount, setSceneCount] = useState<number>(DEFAULT_SCENE_COUNT);
  const [character, setCharacter] = useState<Character | null>(null);
  const [savedId, setSavedId] = useState<string | null>(null);
  const [characterSteps, setCharacterSteps] = useState<StepState[]>(initialCharacterSteps);
  const [sceneSteps, setSceneSteps] = useState<StepState[]>(() =>
    initialSceneSteps(DEFAULT_SCENE_COUNT)
  );
  const [runId, setRunId] = useState<string | null>(null);
  const [sceneRunId, setSceneRunId] = useState<string | null>(null);
  const [inferredProfile, setInferredProfile] = useState<CharacterProfilePreview | undefined>();
  const [profileLoading, setProfileLoading] = useState(false);
  const [profileError, setProfileError] = useState<string | undefined>();
  const [confirmedMeasurements, setConfirmedMeasurements] = useState<Measurements | undefined>();
  const [confirmedProfile, setConfirmedProfile] = useState<ConfirmedProfile | undefined>();
  const stepDataRef = useRef<Partial<Record<CharacterStepId, unknown>>>({});

  const characterChat = useAgentChat();
  const sceneChat = useAgentChat();
  const { settings } = useSettings();
  const superAdmin = settings?.superAdmin ?? false;
  const [autopilot, setAutopilot] = useState(false);

  useChatAutopilot({
    enabled: autopilot,
    messages: characterChat.messages,
    addToolOutput: characterChat.addToolOutput,
  });
  useChatAutopilot({
    enabled: autopilot,
    messages: sceneChat.messages,
    addToolOutput: sceneChat.addToolOutput,
  });

  const activeChat =
    phase === "character-gathering" ||
    phase === "character-profile-review" ||
    phase === "character-generating"
      ? characterChat
      : sceneChat;

  const isStreaming = activeChat.status === "streaming" || activeChat.status === "submitted";

  useEffect(() => {
    const off = window.api.generate.onProgress((ev: GenerateProgressEvent) => {
      if (ev.status === "failed" || ev.status === "refusal-detected") {
        console.error("[generate-progress]", ev);
      } else {
        console.log("[generate-progress]", ev.kind, ev.step, ev.status);
      }
      if (ev.kind === "character") {
        if (runId && ev.runId !== runId) return;
        setCharacterSteps((prev) =>
          prev.map((s) =>
            s.id === ev.step
              ? {
                  ...s,
                  status:
                    ev.status === "started"
                      ? "running"
                      : ev.status === "succeeded"
                        ? "succeeded"
                        : ev.status === "refusal-detected"
                          ? "refusal-detected"
                          : "failed",
                  error: ev.error,
                  usage: ev.usage ?? s.usage,
                  adminOverrideApplied: ev.adminOverrideApplied ?? s.adminOverrideApplied,
                }
              : s
          )
        );
      } else if (ev.kind === "scenes") {
        if (sceneRunId && ev.runId !== sceneRunId) return;
        setSceneSteps((prev) =>
          prev.map((s) =>
            s.id === "scenes"
              ? {
                  ...s,
                  status:
                    ev.status === "started"
                      ? "running"
                      : ev.status === "succeeded"
                        ? "succeeded"
                        : ev.status === "refusal-detected"
                          ? "refusal-detected"
                          : "failed",
                  error: ev.error,
                  usage: ev.usage ?? s.usage,
                  adminOverrideApplied: ev.adminOverrideApplied ?? s.adminOverrideApplied,
                }
              : s
          )
        );
      }
    });
    return () => off();
  }, [runId, sceneRunId]);

  const handleSendCharacter = useCallback(
    async (text: string) => {
      if (characterChat.sessionId) {
        await characterChat.sendMessage({ text });
      } else {
        await characterChat.start({
          flow: "gather-character",
          initialUserMessage: text,
        });
      }
    },
    [characterChat]
  );

  const handleSendScenes = useCallback(
    async (text: string) => {
      if (!character) return;
      if (sceneChat.sessionId) {
        await sceneChat.sendMessage({ text });
      } else {
        await sceneChat.start({
          flow: "gather-scenes",
          character,
          initialUserMessage: text,
        });
      }
    },
    [character, sceneChat]
  );

  const gatheringSummary = useMemo(
    () => characterChat.finalSummary ?? summarizeChat(characterChat.messages),
    [characterChat.finalSummary, characterChat.messages]
  );

  const handleGenerateCharacter = useCallback(async () => {
    setProfileError(undefined);
    setProfileLoading(true);
    setInferredProfile(undefined);
    setConfirmedMeasurements(undefined);
    setConfirmedProfile(undefined);
    setPhase("character-profile-review");

    try {
      if (typeof window.api.generate.inferProfile !== "function") {
        setProfileError(
          "Profile inference is unavailable — restart the app so the preload bridge picks up the latest changes."
        );
        return;
      }
      const res = await window.api.generate.inferProfile({
        gatheringSummary,
        difficulty,
      });
      if (res.success) {
        setInferredProfile(res.profile);
      } else {
        setProfileError(res.error);
      }
    } catch (err) {
      console.error("[inferProfile] threw:", err);
      setProfileError(err instanceof Error ? err.message : String(err));
    } finally {
      setProfileLoading(false);
    }
  }, [gatheringSummary, difficulty]);

  const handleConfirmProfile = useCallback(
    async ({ measurements, profile }: { measurements: Measurements; profile: ConfirmedProfile }) => {
      setConfirmedMeasurements(measurements);
      setConfirmedProfile(profile);
      const id = `char-${Date.now()}`;
      setRunId(id);
      setCharacterSteps(initialCharacterSteps());
      stepDataRef.current = {};
      setPhase("character-generating");

      const result = await window.api.generate.characterAll({
        runId: id,
        difficulty,
        messageLength,
        gatheringSummary,
        imageModel,
        confirmedMeasurements: measurements,
        confirmedProfile: profile,
      });

      if (result.success) {
        setCharacter(result.stored.character);
        setSavedId(result.stored.id);
        setPhase("scene-gathering");
        await sceneChat.start({
          flow: "gather-scenes",
          character: result.stored.character,
          sceneCount,
          initialUserMessage: `We are generating scene prompts for the character "${getFullName(result.stored.character)}". Suggest ${sceneCount} scene ideas that fit this character.`,
        });
      } else {
        for (const [stepId, data] of Object.entries(result.partialByStep)) {
          stepDataRef.current[stepId as CharacterStepId] = data;
        }
      }
    },
    [difficulty, messageLength, imageModel, sceneCount, gatheringSummary, sceneChat]
  );

  const handleBackFromProfile = useCallback(() => {
    setPhase("character-gathering");
    setProfileError(undefined);
    setInferredProfile(undefined);
  }, []);

  const handleRetryCharacterStep = useCallback(
    async (stepId: GenerateStepId) => {
      if (stepId === "scenes") return;
      if (!runId) return;

      setCharacterSteps((prev) =>
        prev.map((s) => (s.id === stepId ? { ...s, status: "running", error: undefined } : s))
      );

      const res = await window.api.generate.characterStep({
        runId,
        stepId: stepId as CharacterStepId,
        difficulty,
        messageLength,
        imageModel,
        gatheringSummary,
        confirmedMeasurements,
        confirmedProfile,
      });

      if (res.success) {
        stepDataRef.current[stepId as CharacterStepId] = res.data;
        const allSucceeded = CHARACTER_STEP_IDS.every(
          (id) => stepDataRef.current[id as CharacterStepId] !== undefined
        );
        if (allSucceeded) {
          const final = await window.api.generate.characterFinalize({
            stepData: stepDataRef.current as Record<CharacterStepId, unknown>,
            difficulty,
            messageLength,
            imageModel,
            confirmedMeasurements,
          });
          if (final.success) {
            setCharacter(final.stored.character);
            setSavedId(final.stored.id);
            setPhase("scene-gathering");
            await sceneChat.start({
              flow: "gather-scenes",
              character: final.stored.character,
              sceneCount,
              initialUserMessage: `We are generating scene prompts for the character "${getFullName(final.stored.character)}". Suggest ${sceneCount} scene ideas that fit this character.`,
            });
          }
        }
      }
    },
    [
      runId,
      difficulty,
      messageLength,
      imageModel,
      sceneCount,
      gatheringSummary,
      sceneChat,
      confirmedMeasurements,
      confirmedProfile,
    ]
  );

  const sceneGatheringSummary = useMemo(
    () => sceneChat.finalSummary ?? summarizeChat(sceneChat.messages),
    [sceneChat.finalSummary, sceneChat.messages]
  );

  const handleGenerateScenes = useCallback(async () => {
    if (!character || !savedId) return;
    const id = `scenes-${Date.now()}`;
    setSceneRunId(id);
    setSceneSteps(initialSceneSteps(sceneCount));
    setPhase("scene-generating");
    await window.api.characters.updateImageModel(savedId, imageModel);
    const result = await window.api.generate.scenes({
      runId: id,
      character,
      gatheringSummary: sceneGatheringSummary,
      imageModel,
      sceneCount,
    });
    if (result.success) {
      await window.api.characters.updateScenes(savedId, result.scenes);
      setPhase("done");
      navigate(`/character/${savedId}`);
    }
  }, [character, savedId, imageModel, sceneCount, sceneGatheringSummary]);

  const handleRetryScenes = useCallback(
    (stepId: GenerateStepId) => {
      if (stepId !== "scenes") return;
      void handleGenerateScenes();
    },
    [handleGenerateScenes]
  );

  const showCharacterGenerate =
    phase === "character-gathering" && characterChat.messages.length > 0 && !isStreaming;
  const showSceneGenerate =
    phase === "scene-gathering" && sceneChat.messages.length > 1 && !isStreaming;
  const hasProgress = characterChat.messages.length > 0 || sceneChat.messages.length > 0;

  const handleStartOver = useCallback(() => {
    void characterChat.stop();
    void sceneChat.stop();
    characterChat.setMessages([]);
    sceneChat.setMessages([]);
    setPhase("character-gathering");
    setDifficulty("medium");
    setMessageLength(DEFAULT_MESSAGE_LENGTH);
    setImageModel(DEFAULT_IMAGE_MODEL);
    setSceneCount(DEFAULT_SCENE_COUNT);
    setCharacter(null);
    setSavedId(null);
    setCharacterSteps(initialCharacterSteps());
    setSceneSteps(initialSceneSteps(DEFAULT_SCENE_COUNT));
    stepDataRef.current = {};
    setRunId(null);
    setSceneRunId(null);
    setInferredProfile(undefined);
    setProfileLoading(false);
    setProfileError(undefined);
    setConfirmedMeasurements(undefined);
    setConfirmedProfile(undefined);
  }, [characterChat, sceneChat]);

  const characterDone =
    phase === "scene-gathering" || phase === "scene-generating" || phase === "done";
  const sceneDone = phase === "done";

  const showCharacterSteps =
    phase === "character-generating" ||
    (phase === "character-gathering" && characterSteps.some((s) => s.status !== "idle"));
  const showSceneSteps =
    phase === "scene-generating" ||
    (phase === "scene-gathering" && sceneSteps.some((s) => s.status !== "idle"));

  const activeStepIndex = characterDone ? 1 : 0;
  const doneCount = sceneDone ? 2 : characterDone ? 1 : 0;

  const subtitle =
    phase === "character-gathering"
      ? "Describe your character concept"
      : phase === "character-profile-review"
        ? "Review profile & measurements"
        : phase === "character-generating"
          ? "Generating character profile..."
          : phase === "scene-gathering"
            ? `Scene ideas for ${character ? getFullName(character) : "..."}`
            : phase === "scene-generating"
              ? "Generating scene prompts..."
              : "Complete!";

  const difficultyReadOnly = phase !== "character-gathering";
  const imageModelReadOnly = phase === "scene-generating" || phase === "done";
  const isGenerating = phase === "character-generating" || phase === "scene-generating";
  const isProfileReview = phase === "character-profile-review";
  const isDone = phase === "done";

  const handleChatSend = useCallback(
    (text: string) => {
      if (phase === "character-gathering") {
        void handleSendCharacter(text);
      } else if (phase === "scene-gathering") {
        void handleSendScenes(text);
      }
    },
    [phase, handleSendCharacter, handleSendScenes]
  );

  const showAutopilotToggle =
    (phase === "character-gathering" && characterChat.messages.length > 0) ||
    (phase === "scene-gathering" && sceneChat.messages.length > 0);

  const hasExtraAbove =
    showCharacterSteps ||
    showSceneSteps ||
    showCharacterGenerate ||
    showSceneGenerate ||
    showAutopilotToggle;

  return (
    <>
      <SubHeaderSlot>
        <SubHeader
          actions={
            <>
              <DifficultyPill
                onChange={setDifficulty}
                readOnly={difficultyReadOnly}
                value={difficulty}
              />
              <MessageLengthPill
                onChange={setMessageLength}
                readOnly={difficultyReadOnly}
                value={messageLength}
              />
              <ImageModelPill
                onChange={setImageModel}
                readOnly={imageModelReadOnly}
                value={imageModel}
              />
              <SceneCountPill
                onChange={(n) => setSceneCount(clampSceneCount(n))}
                readOnly={imageModelReadOnly}
                value={sceneCount}
              />
              {hasProgress && !isGenerating && (
                <Dialog>
                  <DialogTrigger
                    render={
                      <Button
                        className="text-muted-foreground hover:text-destructive"
                        size="icon-sm"
                        variant="ghost"
                      />
                    }
                  >
                    <RotateCcw className="h-3.5 w-3.5" />
                    <span className="sr-only">Start over</span>
                  </DialogTrigger>
                  <DialogContent showCloseButton={false}>
                    <DialogHeader>
                      <DialogTitle>Start over?</DialogTitle>
                      <DialogDescription>
                        This will clear all messages and progress. You'll start from scratch with a
                        new character concept.
                      </DialogDescription>
                    </DialogHeader>
                    <DialogFooter>
                      <DialogClose render={<Button size="sm" variant="outline" />}>
                        Cancel
                      </DialogClose>
                      <DialogClose
                        onClick={handleStartOver}
                        render={<Button size="sm" variant="destructive" />}
                      >
                        <RotateCcw className="mr-1.5 h-3.5 w-3.5" />
                        Start Over
                      </DialogClose>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              )}
            </>
          }
          icon={<Sparkles className="h-4 w-4 text-primary" />}
          stepper={
            <Stepper activeIndex={activeStepIndex} doneCount={doneCount} steps={STEPPER_STEPS} />
          }
          subtitle={subtitle}
          subtitleKey={phase}
          title="Create Character"
        />
      </SubHeaderSlot>

      <ChatDockSlot>
        <ChatDock
          disabled={isStreaming || isGenerating || isProfileReview || isDone}
          extraAbove={
            hasExtraAbove ? (
              <div className="space-y-3">
                {showCharacterSteps && (
                  <GenerationSteps
                    onRetry={handleRetryCharacterStep}
                    steps={characterSteps}
                    superAdmin={superAdmin}
                    title="Character profile"
                  />
                )}
                {showSceneSteps && (
                  <GenerationSteps
                    onRetry={handleRetryScenes}
                    steps={sceneSteps}
                    superAdmin={superAdmin}
                    title="Scenes"
                  />
                )}
                {(showCharacterGenerate || showSceneGenerate || showAutopilotToggle) && (
                  <div className="flex items-center gap-2">
                    {showCharacterGenerate && (
                      <Button className="glow-sm flex-1" onClick={handleGenerateCharacter}>
                        <Sparkles className="mr-2 h-4 w-4" />
                        Generate Character Profile
                      </Button>
                    )}
                    {showSceneGenerate && (
                      <Button className="glow-sm flex-1" onClick={handleGenerateScenes}>
                        <Sparkles className="mr-2 h-4 w-4" />
                        Generate Scene Prompts
                      </Button>
                    )}
                    {showAutopilotToggle && (
                      <div className={showCharacterGenerate || showSceneGenerate ? "" : "ml-auto"}>
                        <AutopilotPill
                          disabled={isGenerating || isDone}
                          enabled={autopilot}
                          onToggle={setAutopilot}
                        />
                      </div>
                    )}
                  </div>
                )}
              </div>
            ) : undefined
          }
          onSend={handleChatSend}
          placeholder={
            phase === "character-gathering"
              ? "Describe your character concept..."
              : "Describe scene ideas or adjustments..."
          }
        />
      </ChatDockSlot>

      <ChatContainer>
        <div className="mx-auto flex w-full max-w-3xl flex-col gap-4">
          {phase === "character-gathering" ||
          phase === "character-profile-review" ||
          phase === "character-generating" ? (
            <>
              {characterChat.messages.length === 0 && (
                <div className="flex flex-col items-center px-4 pt-32 pb-12 text-center">
                  <div className="glow-md mb-6 flex h-20 w-20 items-center justify-center rounded-3xl bg-primary/10">
                    <Wand2 className="h-9 w-9 text-primary" />
                  </div>
                  <h2 className="mb-2 font-semibold text-2xl tracking-tight">
                    What kind of character do you want to create?
                  </h2>
                  <p className="max-w-md text-muted-foreground text-sm leading-relaxed">
                    Describe your concept and the AI will ask follow-up questions to refine the
                    character profile. Adjust the chat difficulty from the pill above.
                  </p>
                </div>
              )}
              {characterChat.messages.map((msg) => (
                <ChatMessage
                  addToolOutput={characterChat.addToolOutput}
                  key={msg.id}
                  message={msg}
                  onDelete={
                    phase === "character-gathering" ? characterChat.deleteMessage : undefined
                  }
                  onEdit={phase === "character-gathering" ? characterChat.editAndResend : undefined}
                  onRegenerateFrom={
                    phase === "character-gathering" ? characterChat.regenerateFrom : undefined
                  }
                />
              ))}
              {isProfileReview && (
                <ProfileReview
                  initial={inferredProfile}
                  loading={profileLoading}
                  error={profileError}
                  difficulty={difficulty}
                  gatheringSummary={gatheringSummary}
                  onConfirm={handleConfirmProfile}
                  onBack={handleBackFromProfile}
                />
              )}
            </>
          ) : (
            <>
              {character && (
                <div className="animate-message-in rounded-xl border border-primary/20 bg-primary/6 p-4">
                  <div className="flex items-center gap-2">
                    <div className="flex h-6 w-6 items-center justify-center rounded-full bg-primary/20">
                      <Check className="h-3 w-3 text-primary" />
                    </div>
                    <p className="font-medium text-primary text-sm">{getFullName(character)}</p>
                  </div>
                  <p className="mt-2 text-muted-foreground text-sm leading-relaxed">
                    {character.publicDescription}
                  </p>
                </div>
              )}
              {sceneChat.messages.map((msg) => (
                <ChatMessage
                  addToolOutput={sceneChat.addToolOutput}
                  key={msg.id}
                  message={msg}
                  onDelete={phase === "scene-gathering" ? sceneChat.deleteMessage : undefined}
                  onEdit={phase === "scene-gathering" ? sceneChat.editAndResend : undefined}
                  onRegenerateFrom={
                    phase === "scene-gathering" ? sceneChat.regenerateFrom : undefined
                  }
                />
              ))}
            </>
          )}

          {activeChat.status === "submitted" && (
            <div className="flex animate-message-in gap-3">
              <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-white/6 text-muted-foreground">
                <Bot className="h-3.5 w-3.5" />
              </div>
              <div className="flex items-center gap-2.5 rounded-2xl rounded-tl-md bg-white/5 px-4 py-3">
                <div className="flex items-center gap-1">
                  <span className="h-1.5 w-1.5 animate-thinking-dot rounded-full bg-primary/70" />
                  <span className="h-1.5 w-1.5 animate-thinking-dot rounded-full bg-primary/70 [animation-delay:200ms]" />
                  <span className="h-1.5 w-1.5 animate-thinking-dot rounded-full bg-primary/70 [animation-delay:400ms]" />
                </div>
                <span className="text-muted-foreground text-xs">Thinking...</span>
              </div>
            </div>
          )}
        </div>
      </ChatContainer>
    </>
  );
}
