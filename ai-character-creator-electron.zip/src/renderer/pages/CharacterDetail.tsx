import { Popover } from "@base-ui/react/popover";
import {
  ArrowLeft,
  ExternalLink,
  Gauge,
  ImagePlus,
  Link as LinkIcon,
  MessageCircle,
  MoreHorizontal,
  RefreshCw,
  Settings2,
  Sparkles,
  Trash2,
} from "lucide-react";
import { ourdreamChatUrl } from "@shared/ourdream-urls";
import { useCallback, useEffect, useState } from "react";
import { AddSceneDialog } from "@/components/add-scene-dialog";
import { CharacterDetail } from "@/components/character-detail";
import { OurDreamUrlDialog } from "@/components/ourdream-url-dialog";
import { QuickEditDialog } from "@/components/quick-edit-dialog";
import { RegenerateDialog } from "@/components/regenerate-dialog";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { navigate } from "@/lib/router";
import type { StoredCharacter } from "@/lib/types";
import { cn } from "@/lib/utils";

function synthGatheringSummary(data: StoredCharacter): string {
  const c = data.character;
  return [
    `Character: ${c.firstName} ${c.lastName}.`,
    `Difficulty: ${data.difficulty}.`,
    `Personality: ${c.personalityLabel}.`,
    `Occupation: ${c.occupationLabel}.`,
    `Relationship: ${c.relationshipLabel}.`,
    `Hobby: ${c.hobbyLabel}.`,
    `Fetish/kink: ${c.fetishLabel}.`,
    "",
    `Public description: ${c.publicDescription}`,
    "",
    `Physical: ${c.customPhysicalDetails}`,
    `Face: ${c.customFaceDetails}`,
    "",
    `Personality details:`,
    c.additionalPersonalityDetails,
    "",
    `Background:`,
    c.extraDetails,
    "",
    `Current scenario:`,
    c.scenario,
  ].join("\n");
}

export function CharacterDetailPage({ id }: { id: string }) {
  const [data, setData] = useState<StoredCharacter | null>(null);
  const [notFound, setNotFound] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [addSceneOpen, setAddSceneOpen] = useState(false);
  const [regenerateOpen, setRegenerateOpen] = useState(false);
  const [quickEditOpen, setQuickEditOpen] = useState(false);
  const [ourdreamOpen, setOurdreamOpen] = useState(false);
  const [moreOpen, setMoreOpen] = useState(false);
  const [moodAxesBusy, setMoodAxesBusy] = useState(false);
  const [moodAxesError, setMoodAxesError] = useState<string | null>(null);

  useEffect(() => {
    window.api.characters.get(id).then((char) => {
      if (char) {
        setData(char);
      } else {
        setNotFound(true);
      }
    });
  }, [id]);

  async function handleDelete() {
    await window.api.characters.delete(id);
    navigate("/");
  }

  const handleSceneAdded = useCallback((updated: StoredCharacter) => {
    setData(updated);
  }, []);

  const handleRegenerateMoodAxes = useCallback(async () => {
    if (!data) return;
    setMoodAxesBusy(true);
    setMoodAxesError(null);
    const res = await window.api.characters.regenerateMoodAxes(
      data.id,
      synthGatheringSummary(data)
    );
    setMoodAxesBusy(false);
    if (res.success) {
      setData(res.stored);
    } else {
      setMoodAxesError(res.error);
    }
  }, [data]);

  if (notFound) {
    return (
      <div className="flex flex-1 min-h-0 flex-col items-center justify-center gap-6">
        <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-muted">
          <Sparkles className="h-6 w-6 text-muted-foreground" />
        </div>
        <div className="text-center">
          <p className="font-semibold text-lg">Character not found</p>
          <p className="mt-1 text-muted-foreground text-sm">
            This character may have been deleted.
          </p>
        </div>
        <a href="#/">
          <Button variant="outline">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Gallery
          </Button>
        </a>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="flex flex-1 min-h-0 items-center justify-center">
        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10">
          <Sparkles className="h-4 w-4 animate-pulse text-primary" />
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-4xl px-4 py-8">
      <div className="mb-8 flex items-center justify-between gap-2">
        <a href="#/">
          <Button className="text-muted-foreground" size="sm" variant="ghost">
            <ArrowLeft className="mr-1 h-4 w-4" />
            Gallery
          </Button>
        </a>
        <div className="flex items-center gap-1.5">
          {data.ourdreamUrl && (
            <>
              <a
                href={ourdreamChatUrl(data.ourdreamUrl)}
                rel="noreferrer noopener"
                target="_blank"
                title="Open chat on OurDream"
              >
                <Button
                  className="text-primary/80 hover:text-primary"
                  size="icon-sm"
                  variant="ghost"
                >
                  <MessageCircle className="h-3.5 w-3.5" />
                </Button>
              </a>
              <a
                href={data.ourdreamUrl}
                rel="noreferrer noopener"
                target="_blank"
                title="Open profile on OurDream"
              >
                <Button
                  className="text-muted-foreground hover:text-foreground"
                  size="icon-sm"
                  variant="ghost"
                >
                  <ExternalLink className="h-3.5 w-3.5" />
                </Button>
              </a>
            </>
          )}
          <Button onClick={() => setQuickEditOpen(true)} size="sm" variant="outline">
            <Settings2 className="mr-1.5 h-3.5 w-3.5" />
            Quick edit
          </Button>
          <Button onClick={() => setAddSceneOpen(true)} size="sm">
            <ImagePlus className="mr-1.5 h-3.5 w-3.5" />
            Add scene
          </Button>
          <Popover.Root onOpenChange={setMoreOpen} open={moreOpen}>
            <Popover.Trigger
              render={
                <Button
                  aria-label="More actions"
                  size="icon-sm"
                  variant="ghost"
                />
              }
            >
              <MoreHorizontal className="h-4 w-4" />
            </Popover.Trigger>
            <Popover.Portal>
              <Popover.Positioner align="end" sideOffset={8}>
                <Popover.Popup className="origin-top-right data-[ending-style]:opacity-0 data-[starting-style]:opacity-0 data-[ending-style]:scale-[0.96] data-[starting-style]:scale-[0.96] transition-all duration-150 ease-out">
                  <div className="w-60 rounded-xl border border-white/8 bg-popover/95 p-1.5 shadow-2xl backdrop-blur-2xl">
                    <MenuItem
                      icon={<RefreshCw className="h-3.5 w-3.5" />}
                      label="Regenerate character"
                      onClick={() => {
                        setMoreOpen(false);
                        setRegenerateOpen(true);
                      }}
                    />
                    <MenuItem
                      icon={<LinkIcon className="h-3.5 w-3.5" />}
                      label={data.ourdreamUrl ? "Edit OurDream link" : "Link to OurDream"}
                      onClick={() => {
                        setMoreOpen(false);
                        setOurdreamOpen(true);
                      }}
                    />
                    {!data.character.moodAxes && (
                      <MenuItem
                        disabled={moodAxesBusy}
                        icon={<Gauge className="h-3.5 w-3.5" />}
                        label={moodAxesBusy ? "Generating…" : "Generate mood axes"}
                        onClick={() => {
                          setMoreOpen(false);
                          void handleRegenerateMoodAxes();
                        }}
                      />
                    )}
                    <div className="my-1 h-px bg-white/6" />
                    <MenuItem
                      destructive
                      icon={<Trash2 className="h-3.5 w-3.5" />}
                      label="Delete character"
                      onClick={() => {
                        setMoreOpen(false);
                        setDeleteOpen(true);
                      }}
                    />
                  </div>
                </Popover.Popup>
              </Popover.Positioner>
            </Popover.Portal>
          </Popover.Root>
        </div>
      </div>

      {moodAxesError && (
        <div className="mb-4 rounded-lg border border-destructive/40 bg-destructive/10 px-3 py-2 text-destructive text-xs">
          Mood axes generation failed: {moodAxesError}
        </div>
      )}

      <CharacterDetail data={data} />

      <AddSceneDialog
        character={data}
        onOpenChange={setAddSceneOpen}
        onSceneAdded={handleSceneAdded}
        open={addSceneOpen}
      />

      <RegenerateDialog data={data} onOpenChange={setRegenerateOpen} open={regenerateOpen} />

      <QuickEditDialog
        data={data}
        gatheringSummary={synthGatheringSummary(data)}
        onOpenChange={setQuickEditOpen}
        onUpdated={setData}
        open={quickEditOpen}
      />

      <OurDreamUrlDialog
        data={data}
        onOpenChange={setOurdreamOpen}
        onUpdated={setData}
        open={ourdreamOpen}
      />

      <Dialog onOpenChange={setDeleteOpen} open={deleteOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete character</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this character? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button onClick={() => setDeleteOpen(false)} variant="outline">
              Cancel
            </Button>
            <Button onClick={handleDelete} variant="destructive">
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function MenuItem({
  destructive,
  disabled,
  icon,
  label,
  onClick,
}: {
  destructive?: boolean;
  disabled?: boolean;
  icon: React.ReactNode;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      className={cn(
        "flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-left text-sm transition-colors",
        destructive
          ? "text-destructive hover:bg-destructive/10"
          : "hover:bg-white/5",
        disabled && "pointer-events-none opacity-50"
      )}
      disabled={disabled}
      onClick={onClick}
      type="button"
    >
      <span
        className={cn(
          "flex h-6 w-6 shrink-0 items-center justify-center rounded-md",
          destructive ? "bg-destructive/10" : "bg-white/6"
        )}
      >
        {icon}
      </span>
      <span className="flex-1 truncate">{label}</span>
    </button>
  );
}
