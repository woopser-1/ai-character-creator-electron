import type { ImageModel } from "@shared/schemas";

export * from "@shared/schemas";

export const IMAGE_MODEL_META: Record<
  ImageModel,
  { label: string; description: string; color: string }
> = {
  Dreamy: {
    label: "Dreamy",
    description: "Tag-style positive + negative prompts (new format)",
    color: "text-violet-400 bg-violet-500/15",
  },
  Vivid: {
    label: "Vivid",
    description: "Flowing sentence ending with 'photorealistic'",
    color: "text-amber-400 bg-amber-500/15",
  },
  "Vivid 2": {
    label: "Vivid 2",
    description: "Same schema as Vivid, next-gen quality",
    color: "text-sky-400 bg-sky-500/15",
  },
  "Vivid 3": {
    label: "Vivid 3",
    description: "Natural-language descriptive prose, no tags or weights",
    color: "text-emerald-400 bg-emerald-500/15",
  },
};
