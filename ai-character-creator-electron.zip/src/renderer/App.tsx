import { AnimatePresence, motion } from "motion/react";
import { ClaudeStatusBanner } from "@/components/claude-status-banner";
import { NavHeader } from "@/components/nav-header";
import { ChromeProvider, useChromeRefs } from "@/lib/chrome-context";
import { useRoute } from "@/lib/router";
import { CharacterDetailPage } from "@/pages/CharacterDetail";
import { CreatePage } from "@/pages/Create";
import { GalleryPage } from "@/pages/Gallery";
import { RegeneratePage } from "@/pages/Regenerate";
import { SettingsPage } from "@/pages/Settings";

export function App() {
  return (
    <ChromeProvider>
      <AppShell />
    </ChromeProvider>
  );
}

function AppShell() {
  const route = useRoute();
  const { setSubHeaderEl, setChatDockEl } = useChromeRefs();

  return (
    <div className="flex h-screen flex-col overflow-hidden">
      <NavHeader />
      <ClaudeStatusBanner />
      <div className="shrink-0" ref={setSubHeaderEl} />
      <AnimatePresence initial={false} mode="wait">
        <motion.main
          animate={{ opacity: 1, y: 0 }}
          className="flex min-h-0 flex-1 flex-col overflow-y-auto"
          exit={{ opacity: 0, y: -4 }}
          initial={{ opacity: 0, y: 6 }}
          key={route.name}
          transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
        >
          {route.name === "gallery" && <GalleryPage />}
          {route.name === "create" && <CreatePage />}
          {route.name === "settings" && <SettingsPage />}
          {route.name === "character" && <CharacterDetailPage id={route.id} />}
          {route.name === "regenerate" && <RegeneratePage id={route.id} />}
        </motion.main>
      </AnimatePresence>
      <div className="shrink-0" ref={setChatDockEl} />
    </div>
  );
}
