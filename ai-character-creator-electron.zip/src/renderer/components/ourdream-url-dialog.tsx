import {
  ExternalLink,
  Image as ImageIcon,
  Loader2,
  MessageCircle,
  Trash2,
} from "lucide-react";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { ourdreamChatUrl } from "@shared/ourdream-urls";
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import type { StoredCharacter } from "@/lib/types";

interface OurDreamUrlDialogProps {
  data: StoredCharacter;
  onOpenChange: (open: boolean) => void;
  onUpdated: (next: StoredCharacter) => void;
  open: boolean;
}

export function OurDreamUrlDialog({
  data,
  onOpenChange,
  onUpdated,
  open,
}: OurDreamUrlDialogProps) {
  const [url, setUrl] = useState(data.ourdreamUrl ?? "");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (open) {
      setUrl(data.ourdreamUrl ?? "");
      setError(null);
      setBusy(false);
    }
  }, [open, data.ourdreamUrl]);

  async function handleSave() {
    setBusy(true);
    setError(null);
    const trimmed = url.trim();
    const res = await window.api.characters.updateOurdreamUrl(
      data.id,
      trimmed.length > 0 ? trimmed : null
    );
    setBusy(false);
    if (res.success) {
      onUpdated(res.stored);
      onOpenChange(false);
    } else {
      setError(res.error);
    }
  }

  async function handleRefresh() {
    setBusy(true);
    setError(null);
    const res = await window.api.characters.refreshProfileImage(data.id);
    setBusy(false);
    if (res.success) {
      onUpdated(res.stored);
    } else {
      setError(res.error);
    }
  }

  async function handleClear() {
    setBusy(true);
    setError(null);
    const res = await window.api.characters.updateOurdreamUrl(data.id, null);
    setBusy(false);
    if (res.success) {
      onUpdated(res.stored);
      setUrl("");
    } else {
      setError(res.error);
    }
  }

  return (
    <Dialog onOpenChange={onOpenChange} open={open}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ImageIcon className="h-4 w-4 text-primary" />
            OurDream link
          </DialogTitle>
          <DialogDescription>
            Paste the public OurDream URL for this character. We'll pull the
            profile image and let you jump straight back to the page later.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3">
          <div className="space-y-2.5">
            <label
              className="font-medium text-muted-foreground text-xs uppercase tracking-wider"
              htmlFor="ourdream-url"
            >
              Character URL
            </label>
            <Input
              autoComplete="off"
              disabled={busy}
              id="ourdream-url"
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://ourdream.ai/c/..."
              spellCheck={false}
              value={url}
            />
          </div>

          {data.profileImageUrl && (
            <div className="flex items-start gap-3 rounded-lg border border-white/6 bg-white/3 p-3">
              <img
                alt="Profile preview"
                className="h-20 w-20 shrink-0 rounded-lg border border-white/10 object-cover"
                src={data.profileImageUrl}
              />
              <div className="min-w-0 flex-1 space-y-1">
                <div className="font-medium text-muted-foreground text-xs uppercase tracking-wider">
                  Saved profile image
                </div>
                <div className="break-all font-mono text-[10px] text-muted-foreground/70 leading-snug">
                  {data.profileImageUrl}
                </div>
                {data.ourdreamUrl && (
                  <div className="-mx-1 mt-0.5 flex flex-wrap items-center gap-1">
                    <a
                      className="inline-flex h-6 items-center gap-1 rounded-md px-1 text-[11px] text-primary/80 hover:bg-primary/10 hover:text-primary"
                      href={ourdreamChatUrl(data.ourdreamUrl)}
                      rel="noreferrer noopener"
                      target="_blank"
                    >
                      <MessageCircle className="h-3 w-3" />
                      Open chat
                    </a>
                    <a
                      className="inline-flex h-6 items-center gap-1 rounded-md px-1 text-[11px] text-muted-foreground hover:bg-white/5 hover:text-foreground"
                      href={data.ourdreamUrl}
                      rel="noreferrer noopener"
                      target="_blank"
                    >
                      <ExternalLink className="h-3 w-3" />
                      Profile
                    </a>
                  </div>
                )}
              </div>
            </div>
          )}

          {error && (
            <p className="text-destructive text-xs leading-relaxed">{error}</p>
          )}
        </div>

        <DialogFooter className="sm:justify-between">
          {data.ourdreamUrl ? (
            <Button
              className="text-destructive hover:text-destructive"
              disabled={busy}
              onClick={() => void handleClear()}
              size="sm"
              variant="ghost"
            >
              <Trash2 className="mr-1.5 h-3.5 w-3.5" />
              Remove
            </Button>
          ) : (
            <span />
          )}
          <div className="flex flex-row-reverse gap-2">
            <Button
              disabled={busy || url.trim().length === 0}
              onClick={() => void handleSave()}
              size="sm"
            >
              {busy && <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" />}
              {data.profileImageUrl ? "Update" : "Save & extract image"}
            </Button>
            {data.ourdreamUrl && data.ourdreamUrl === url.trim() && (
              <Button
                disabled={busy}
                onClick={() => void handleRefresh()}
                size="sm"
                variant="outline"
              >
                Refresh image
              </Button>
            )}
            <DialogClose render={<Button size="sm" variant="outline" />}>
              Cancel
            </DialogClose>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
