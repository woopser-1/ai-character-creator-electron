import { Sparkles } from "lucide-react"

export const AUTOPILOT_SENTINEL = "__AUTOPILOT__"

interface AutopilotBadgeProps {
  label?: string
}

export function AutopilotBadge({ label = "Let AI decide" }: AutopilotBadgeProps) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-lg border border-primary/30 border-dashed bg-gradient-to-r from-primary/15 to-primary/5 px-3 py-1.5 font-medium text-primary text-sm italic">
      <Sparkles className="h-3 w-3" />
      {label}
    </span>
  )
}

export function isAutopilot(value: string | undefined | null): boolean {
  return value === AUTOPILOT_SENTINEL
}
