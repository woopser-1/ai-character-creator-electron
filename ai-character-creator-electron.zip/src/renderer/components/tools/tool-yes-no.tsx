
import { Check, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  AUTOPILOT_SENTINEL,
  AutopilotBadge,
  isAutopilot,
} from "@/components/tools/autopilot-badge"

interface ToolYesNoProps {
  onSubmit: (result: string) => void
  question: string
  submitted?: boolean
  submittedValue?: string
}

export function ToolYesNo({
  question,
  onSubmit,
  submitted,
  submittedValue,
}: ToolYesNoProps) {
  if (submitted) {
    return (
      <div className="rounded-xl border border-white/6 bg-white/3 p-4 transition-all duration-300">
        <p className="mb-2.5 text-muted-foreground text-sm">{question}</p>
        {isAutopilot(submittedValue) ? (
          <AutopilotBadge />
        ) : (
          <div className="inline-flex items-center gap-1.5 rounded-lg bg-primary/15 px-3 py-1.5 font-medium text-primary text-sm">
            <Check className="h-3 w-3" />
            {submittedValue}
          </div>
        )}
      </div>
    )
  }

  return (
    <div className="animate-tool-in space-y-3 rounded-xl border border-white/8 bg-white/3 p-4">
      <p className="font-medium text-sm">{question}</p>
      <div className="flex gap-2">
        <Button onClick={() => onSubmit("Yes")} size="sm">
          Yes
        </Button>
        <Button onClick={() => onSubmit("No")} size="sm" variant="outline">
          No
        </Button>
        <Button
          onClick={() => onSubmit(AUTOPILOT_SENTINEL)}
          size="sm"
          variant="outline"
        >
          <Sparkles className="mr-1 h-3 w-3" />
          Let AI decide
        </Button>
      </div>
    </div>
  )
}
