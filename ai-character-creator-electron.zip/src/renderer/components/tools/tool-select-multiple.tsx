
import { Check, Plus, Sparkles, X } from "lucide-react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { cn } from "@/lib/utils"
import {
  AUTOPILOT_SENTINEL,
  AutopilotBadge,
  isAutopilot,
} from "@/components/tools/autopilot-badge"

interface ToolSelectMultipleProps {
  onSubmit: (result: string) => void
  options: string[]
  question: string
  submitted?: boolean
  submittedValue?: string
}

export function ToolSelectMultiple({
  question,
  options,
  onSubmit,
  submitted,
  submittedValue,
}: ToolSelectMultipleProps) {
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [customItems, setCustomItems] = useState<string[]>([])
  const [customInput, setCustomInput] = useState("")
  const [showCustomInput, setShowCustomInput] = useState(false)

  const allOptions = [...options, ...customItems]

  function toggle(option: string) {
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(option)) {
        next.delete(option)
      } else {
        next.add(option)
      }
      return next
    })
  }

  function addCustomItem() {
    const trimmed = customInput.trim()
    if (!trimmed || allOptions.includes(trimmed)) {
      return
    }
    setCustomItems((prev) => [...prev, trimmed])
    setSelected((prev) => new Set(prev).add(trimmed))
    setCustomInput("")
  }

  function removeCustomItem(item: string) {
    setCustomItems((prev) => prev.filter((i) => i !== item))
    setSelected((prev) => {
      const next = new Set(prev)
      next.delete(item)
      return next
    })
  }

  if (submitted) {
    return (
      <div className="rounded-xl border border-white/6 bg-white/3 p-4 transition-all duration-300">
        <p className="mb-2.5 text-muted-foreground text-sm">{question}</p>
        {isAutopilot(submittedValue) ? (
          <AutopilotBadge />
        ) : (
          <div className="flex flex-wrap gap-1.5">
            {(submittedValue ?? "")
              .split("\n")
              .map((v) => v.trim())
              .filter(Boolean)
              .map((v) => (
                <span
                  className="inline-flex items-center gap-1 rounded-lg bg-primary/15 px-2.5 py-1 font-medium text-primary text-xs"
                  key={v}
                >
                  <Check className="h-2.5 w-2.5" />
                  {v}
                </span>
              ))}
          </div>
        )}
      </div>
    )
  }

  return (
    <div className="animate-tool-in space-y-3 rounded-xl border border-white/8 bg-white/3 p-4">
      <p className="font-medium text-sm">{question}</p>
      <div className="flex flex-wrap gap-2">
        {options.map((option) => (
          <button
            className={cn(
              "inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-sm transition-all",
              selected.has(option)
                ? "glow-sm border-primary/40 bg-primary/15 text-primary"
                : "border-white/8 bg-white/3 text-foreground hover:border-white/15 hover:bg-white/6"
            )}
            key={option}
            onClick={() => toggle(option)}
            type="button"
          >
            {selected.has(option) && <Check className="h-3 w-3" />}
            {option}
          </button>
        ))}
        {customItems.map((item) => (
          <span
            className={cn(
              "inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-sm transition-all",
              selected.has(item)
                ? "glow-sm border-primary/40 bg-primary/15 text-primary"
                : "border-white/8 bg-white/3 text-foreground hover:border-white/15 hover:bg-white/6"
            )}
            key={item}
          >
            <button
              className="inline-flex items-center gap-1.5"
              onClick={() => toggle(item)}
              type="button"
            >
              {selected.has(item) && <Check className="h-3 w-3" />}
              {item}
            </button>
            <button
              className="ml-0.5 rounded-full p-0.5 opacity-60 hover:bg-white/10 hover:opacity-100"
              onClick={() => removeCustomItem(item)}
              type="button"
            >
              <X className="h-2.5 w-2.5" />
            </button>
          </span>
        ))}
        <button
          className={cn(
            "inline-flex items-center gap-1.5 rounded-lg border border-dashed px-3 py-1.5 text-sm transition-all",
            showCustomInput
              ? "border-primary/40 bg-primary/15 text-primary"
              : "border-white/10 text-muted-foreground hover:border-white/20 hover:text-foreground"
          )}
          onClick={() => setShowCustomInput(!showCustomInput)}
          type="button"
        >
          <Plus className="h-3 w-3" />
          Add custom
        </button>
      </div>

      {showCustomInput && (
        <div className="flex gap-2">
          <Input
            autoFocus
            className="border-white/8 bg-white/3"
            onChange={(e) => setCustomInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && customInput.trim()) {
                addCustomItem()
              }
            }}
            placeholder="Type a custom option and press Enter..."
            value={customInput}
          />
          <Button
            disabled={!customInput.trim()}
            onClick={addCustomItem}
            size="sm"
            variant="outline"
          >
            Add
          </Button>
        </div>
      )}

      <div className="flex gap-2">
        <Button
          disabled={selected.size === 0}
          onClick={() => {
            const result = Array.from(selected).join("\n")
            onSubmit(result || "None selected")
          }}
          size="sm"
        >
          Confirm ({selected.size} selected)
        </Button>
        {options.length > 0 && (
          <Button
            onClick={() => onSubmit(AUTOPILOT_SENTINEL)}
            size="sm"
            variant="outline"
          >
            <Sparkles className="mr-1 h-3 w-3" />
            Let AI decide
          </Button>
        )}
      </div>
    </div>
  )
}
