
import { Check, Sparkles } from "lucide-react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { cn } from "@/lib/utils"
import {
  AUTOPILOT_SENTINEL,
  AutopilotBadge,
  isAutopilot,
} from "@/components/tools/autopilot-badge"

interface ToolSuggestOptionsProps {
  onSubmit: (result: string) => void
  options: string[]
  question: string
  submitted?: boolean
  submittedValue?: string
}

export function ToolSuggestOptions({
  question,
  options,
  onSubmit,
  submitted,
  submittedValue,
}: ToolSuggestOptionsProps) {
  const [selected, setSelected] = useState<string | null>(null)
  const [customMode, setCustomMode] = useState(false)
  const [customValue, setCustomValue] = useState("")

  if (submitted) {
    return (
      <div className="rounded-xl border border-white/6 bg-white/3 p-4 transition-all duration-300">
        <p className="mb-2.5 text-muted-foreground text-sm">{question}</p>
        {isAutopilot(submittedValue) ? (
          <AutopilotBadge />
        ) : (
          <div className="inline-flex items-center gap-1.5 rounded-lg bg-primary/15 px-3 py-1.5 font-medium text-primary text-sm">
            <Check className="h-3 w-3" />
            {submittedValue}
          </div>
        )}
      </div>
    )
  }

  return (
    <div className="animate-tool-in space-y-3 rounded-xl border border-white/8 bg-white/3 p-4">
      <p className="font-medium text-sm">{question}</p>
      <div className="flex flex-wrap gap-2">
        {options.map((option) => (
          <button
            className={cn(
              "rounded-lg border px-3 py-1.5 text-sm transition-all",
              selected === option
                ? "glow-sm border-primary/40 bg-primary/15 text-primary"
                : "border-white/8 bg-white/3 text-foreground hover:border-white/15 hover:bg-white/6"
            )}
            key={option}
            onClick={() => {
              setSelected(option)
              setCustomMode(false)
            }}
            type="button"
          >
            {option}
          </button>
        ))}
        <button
          className={cn(
            "rounded-lg border border-dashed px-3 py-1.5 text-sm transition-all",
            customMode
              ? "border-primary/40 bg-primary/15 text-primary"
              : "border-white/10 text-muted-foreground hover:border-white/20 hover:text-foreground"
          )}
          onClick={() => {
            setCustomMode(true)
            setSelected(null)
          }}
          type="button"
        >
          Custom...
        </button>
      </div>

      {customMode && (
        <Input
          autoFocus
          className="border-white/8 bg-white/3"
          onChange={(e) => setCustomValue(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && customValue.trim()) {
              onSubmit(customValue.trim())
            }
          }}
          placeholder="Type your own answer..."
          value={customValue}
        />
      )}

      <div className="flex gap-2">
        <Button
          disabled={!(selected || (customMode && customValue.trim()))}
          onClick={() => {
            if (customMode && customValue.trim()) {
              onSubmit(customValue.trim())
            } else if (selected) {
              onSubmit(selected)
            }
          }}
          size="sm"
        >
          Confirm
        </Button>
        {options.length > 0 && (
          <Button
            onClick={() => onSubmit(AUTOPILOT_SENTINEL)}
            size="sm"
            variant="outline"
          >
            <Sparkles className="mr-1 h-3 w-3" />
            Let AI decide
          </Button>
        )}
      </div>
    </div>
  )
}
