
import { Sparkles } from "lucide-react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import {
  AUTOPILOT_SENTINEL,
  AutopilotBadge,
  isAutopilot,
} from "@/components/tools/autopilot-badge"

interface ToolAskUserProps {
  onSubmit: (result: string) => void
  question: string
  submitted?: boolean
  submittedValue?: string
}

export function ToolAskUser({
  question,
  onSubmit,
  submitted,
  submittedValue,
}: ToolAskUserProps) {
  const [value, setValue] = useState("")

  if (submitted) {
    return (
      <div className="rounded-xl border border-white/6 bg-white/3 p-4 transition-all duration-300">
        <p className="mb-2.5 text-muted-foreground text-sm">{question}</p>
        {isAutopilot(submittedValue) ? (
          <AutopilotBadge />
        ) : (
          <p className="text-sm">{submittedValue}</p>
        )}
      </div>
    )
  }

  return (
    <div className="animate-tool-in space-y-3 rounded-xl border border-white/8 bg-white/3 p-4">
      <p className="font-medium text-sm">{question}</p>
      <Textarea
        className="border-white/8 bg-white/3"
        onChange={(e) => setValue(e.target.value)}
        placeholder="Type your answer..."
        rows={3}
        value={value}
      />
      <div className="flex gap-2">
        <Button
          disabled={!value.trim()}
          onClick={() => onSubmit(value.trim())}
          size="sm"
        >
          Submit
        </Button>
        <Button
          onClick={() => onSubmit(AUTOPILOT_SENTINEL)}
          size="sm"
          variant="outline"
        >
          <Sparkles className="mr-1 h-3 w-3" />
          Let AI decide
        </Button>
      </div>
    </div>
  )
}
