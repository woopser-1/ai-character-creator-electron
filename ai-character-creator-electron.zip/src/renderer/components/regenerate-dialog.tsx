
import { RefreshCw } from "lucide-react"
import { navigate } from "@/lib/router"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import type { StoredCharacter } from "@/lib/types"
import { getFullName } from "@/lib/types"

interface RegenerateDialogProps {
  data: StoredCharacter
  onOpenChange: (open: boolean) => void
  open: boolean
}

export function RegenerateDialog({
  data,
  open,
  onOpenChange,
}: RegenerateDialogProps) {
  return (
    <Dialog onOpenChange={onOpenChange} open={open}>
      <DialogContent className="sm:max-w-md" showCloseButton>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <RefreshCw className="h-4 w-4 text-primary" />
            Regenerate Character
          </DialogTitle>
          <DialogDescription>
            You'll be taken to an interactive session where you can choose which
            areas of {getFullName(data.character)} to regenerate, adjust the
            difficulty, and answer targeted questions before regeneration.
          </DialogDescription>
        </DialogHeader>
        <DialogFooter>
          <Button onClick={() => onOpenChange(false)} variant="outline">
            Cancel
          </Button>
          <Button
            className="glow-sm"
            onClick={() => {
              onOpenChange(false)
              navigate(`/regenerate/${data.id}`)
            }}
          >
            <RefreshCw className="mr-2 h-4 w-4" />
            Start Regeneration
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
