import { ExternalLink, MessageCircle, Palette, Shield, Sparkles } from "lucide-react";
import type { MouseEvent } from "react";
import { Badge } from "@/components/ui/badge";
import type { StoredCharacter } from "@/lib/types";
import {
  DIFFICULTY_META,
  getFullName,
  getStoredImageModel,
  IMAGE_MODEL_META,
} from "@/lib/types";
import { ourdreamChatUrl } from "@shared/ourdream-urls";

interface CharacterCardProps {
  data: StoredCharacter;
}

function openExternal(url: string) {
  return (e: MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();
    e.stopPropagation();
    window.open(url, "_blank", "noopener,noreferrer");
  };
}

export function CharacterCard({ data }: CharacterCardProps) {
  const { character } = data;
  const difficulty = data.difficulty ?? "medium";
  const diffMeta = DIFFICULTY_META[difficulty];
  const imageModel = getStoredImageModel(data);
  const imageModelMeta = IMAGE_MODEL_META[imageModel];

  if (data.profileImageUrl) {
    return (
      <a href={`#/character/${data.id}`}>
        <div className="group hover:glow-sm flex h-full cursor-pointer flex-col overflow-hidden rounded-xl border border-white/6 bg-white/2 transition-all hover:border-primary/30 hover:bg-white/4">
          <div className="relative aspect-[4/5] overflow-hidden bg-black/40">
            <img
              alt={getFullName(character)}
              className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
              loading="lazy"
              src={data.profileImageUrl}
            />
            <div className="absolute top-2.5 right-2.5 flex flex-wrap items-center justify-end gap-1.5">
              <span
                className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 font-medium text-[10px] backdrop-blur-md ${diffMeta.color}`}
              >
                <Shield className="h-2.5 w-2.5" />
                {diffMeta.label}
              </span>
              <span
                className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 font-medium text-[10px] backdrop-blur-md ${imageModelMeta.color}`}
                title={imageModelMeta.description}
              >
                <Palette className="h-2.5 w-2.5" />
                {imageModelMeta.label}
              </span>
            </div>
            {data.ourdreamUrl && (
              <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5 opacity-0 transition-opacity group-hover:opacity-100 focus-within:opacity-100">
                <button
                  aria-label="Open chat with this character"
                  className="flex h-7 w-7 items-center justify-center rounded-full bg-primary/85 text-primary-foreground backdrop-blur-md transition-colors hover:bg-primary"
                  onClick={openExternal(ourdreamChatUrl(data.ourdreamUrl))}
                  title="Open chat on OurDream"
                  type="button"
                >
                  <MessageCircle className="h-3.5 w-3.5" />
                </button>
                <button
                  aria-label="Open profile on OurDream"
                  className="flex h-7 w-7 items-center justify-center rounded-full bg-black/60 text-white/90 backdrop-blur-md transition-colors hover:bg-black/80 hover:text-white"
                  onClick={openExternal(data.ourdreamUrl)}
                  title="Open profile on OurDream"
                  type="button"
                >
                  <ExternalLink className="h-3.5 w-3.5" />
                </button>
              </div>
            )}
            <div className="pointer-events-none absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/85 via-black/40 to-transparent p-4 pt-12">
              <h3 className="font-semibold text-lg text-white tracking-tight drop-shadow-md">
                {getFullName(character)}
              </h3>
            </div>
          </div>

          <div className="flex flex-1 flex-col p-4">
            <p className="mb-3 line-clamp-2 text-muted-foreground text-sm leading-relaxed">
              {character.publicDescription}
            </p>
            <div className="mb-3 flex flex-wrap gap-1.5">
              <Badge className="text-xs" variant="secondary">
                {character.personalityLabel}
              </Badge>
              <Badge className="text-xs" variant="secondary">
                {character.occupationLabel}
              </Badge>
              <Badge className="text-xs" variant="outline">
                {character.relationshipLabel}
              </Badge>
            </div>
            <div className="mt-auto flex items-center justify-between border-white/6 border-t pt-3 text-muted-foreground text-xs">
              <div className="flex items-center gap-2">
                <span>{data.scenes.length} scenes</span>
                <span className="text-white/15">&middot;</span>
                <span className="text-muted-foreground/60">
                  {new Date(data.createdAt).toLocaleDateString()}
                </span>
              </div>
            </div>
          </div>
        </div>
      </a>
    );
  }

  return (
    <a href={`#/character/${data.id}`}>
      <div className="group hover:glow-sm h-full cursor-pointer rounded-xl border border-white/6 bg-white/2 p-5 transition-all hover:border-primary/30 hover:bg-white/4">
        <div className="mb-3 flex items-start justify-between gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary/10 text-primary transition-transform group-hover:scale-105">
            <Sparkles className="h-4 w-4" />
          </div>
          <div className="flex flex-wrap items-center justify-end gap-1.5">
            {data.ourdreamUrl && (
              <>
                <button
                  aria-label="Open chat with this character"
                  className="inline-flex h-5 w-5 items-center justify-center rounded-full text-primary/80 transition-colors hover:bg-primary/15 hover:text-primary"
                  onClick={openExternal(ourdreamChatUrl(data.ourdreamUrl))}
                  title="Open chat on OurDream"
                  type="button"
                >
                  <MessageCircle className="h-3 w-3" />
                </button>
                <button
                  aria-label="Open profile on OurDream"
                  className="inline-flex h-5 w-5 items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-white/8 hover:text-foreground"
                  onClick={openExternal(data.ourdreamUrl)}
                  title="Open profile on OurDream"
                  type="button"
                >
                  <ExternalLink className="h-3 w-3" />
                </button>
              </>
            )}
            <span
              className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 font-medium text-[10px] ${diffMeta.color}`}
            >
              <Shield className="h-2.5 w-2.5" />
              {diffMeta.label}
            </span>
            <span
              className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 font-medium text-[10px] ${imageModelMeta.color}`}
              title={imageModelMeta.description}
            >
              <Palette className="h-2.5 w-2.5" />
              {imageModelMeta.label}
            </span>
          </div>
        </div>
        <h3 className="mb-1 font-semibold text-base tracking-tight">{getFullName(character)}</h3>
        <p className="mb-3 line-clamp-2 text-muted-foreground text-sm leading-relaxed">
          {character.publicDescription}
        </p>
        <div className="mb-3 flex flex-wrap gap-1.5">
          <Badge className="text-xs" variant="secondary">
            {character.personalityLabel}
          </Badge>
          <Badge className="text-xs" variant="secondary">
            {character.occupationLabel}
          </Badge>
          <Badge className="text-xs" variant="outline">
            {character.relationshipLabel}
          </Badge>
        </div>

        <div className="flex items-center justify-between border-white/6 border-t pt-3 text-muted-foreground text-xs">
          <div className="flex items-center gap-2">
            <span>{data.scenes.length} scenes</span>
            <span className="text-white/15">&middot;</span>
            <span className="text-muted-foreground/60">
              {new Date(data.createdAt).toLocaleDateString()}
            </span>
          </div>
        </div>
      </div>
    </a>
  );
}
