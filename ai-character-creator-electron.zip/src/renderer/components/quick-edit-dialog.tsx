import { Loader2, MessageSquare, Palette, Shield, Sparkles } from "lucide-react";
import { useCallback, useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DEFAULT_IMAGE_MODEL,
  DEFAULT_MESSAGE_LENGTH,
  DIFFICULTIES,
  type Difficulty,
  DIFFICULTY_META,
  IMAGE_MODEL_META,
  IMAGE_MODELS,
  type ImageModel,
  MESSAGE_LENGTH_META,
  MESSAGE_LENGTHS,
  type MessageLength,
  type StoredCharacter,
} from "@/lib/types";
import { cn } from "@/lib/utils";

interface QuickEditDialogProps {
  data: StoredCharacter;
  gatheringSummary: string;
  onOpenChange: (open: boolean) => void;
  onUpdated: (next: StoredCharacter) => void;
  open: boolean;
}

type RunStage = "idle" | "scenario" | "difficulty" | "scenes";

const STAGE_LABEL: Record<Exclude<RunStage, "idle">, string> = {
  scenario: "Re-running scenario for new reply length…",
  difficulty: "Regenerating mood / intimacy / scenario for new difficulty…",
  scenes: "Regenerating all scenes for the new image model…",
};

export function QuickEditDialog({
  data,
  gatheringSummary,
  onOpenChange,
  onUpdated,
  open,
}: QuickEditDialogProps) {
  const storedLength = data.messageLength ?? DEFAULT_MESSAGE_LENGTH;
  const storedDifficulty = data.difficulty;
  const storedModel = data.imageModel ?? DEFAULT_IMAGE_MODEL;

  const [draftLength, setDraftLength] = useState<MessageLength>(storedLength);
  const [draftDifficulty, setDraftDifficulty] =
    useState<Difficulty>(storedDifficulty);
  const [draftModel, setDraftModel] = useState<ImageModel>(storedModel);
  const [stage, setStage] = useState<RunStage>("idle");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (open) {
      setDraftLength(storedLength);
      setDraftDifficulty(storedDifficulty);
      setDraftModel(storedModel);
      setStage("idle");
      setError(null);
    }
  }, [open, storedLength, storedDifficulty, storedModel]);

  const lengthChanged = draftLength !== storedLength;
  const difficultyChanged = draftDifficulty !== storedDifficulty;
  const modelChanged = draftModel !== storedModel;
  const hasChanges = lengthChanged || difficultyChanged || modelChanged;
  const busy = stage !== "idle";

  const handleSubmit = useCallback(async () => {
    if (!hasChanges || busy) return;
    setError(null);

    let current: StoredCharacter = data;

    if (lengthChanged) {
      setStage("scenario");
      const res = await window.api.characters.updateMessageLength(
        current.id,
        draftLength,
        gatheringSummary
      );
      if (!res.success) {
        setStage("idle");
        setError(res.error);
        return;
      }
      current = res.stored;
      onUpdated(current);
    }

    if (difficultyChanged) {
      setStage("difficulty");
      const res = await window.api.characters.regenerateForDifficulty(
        current.id,
        draftDifficulty,
        gatheringSummary
      );
      if (!res.success) {
        setStage("idle");
        setError(res.error);
        return;
      }
      current = res.stored;
      onUpdated(current);
    }

    if (modelChanged) {
      setStage("scenes");
      const res = await window.api.characters.regenerateScenes(
        current.id,
        draftModel
      );
      if (!res.success) {
        setStage("idle");
        setError(res.error);
        return;
      }
      current = res.stored;
      onUpdated(current);
    }

    setStage("idle");
    onOpenChange(false);
  }, [
    busy,
    data,
    difficultyChanged,
    draftDifficulty,
    draftLength,
    draftModel,
    gatheringSummary,
    hasChanges,
    lengthChanged,
    modelChanged,
    onOpenChange,
    onUpdated,
  ]);

  return (
    <Dialog
      onOpenChange={(next) => {
        if (busy) return;
        onOpenChange(next);
      }}
      open={open}
    >
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-primary" />
            Quick edit
          </DialogTitle>
          <DialogDescription>
            Stage the changes you want and hit Submit — we'll re-run only the
            parts of the character that are affected.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-5">
          <Section
            description={
              lengthChanged
                ? "Will re-run the scenario step to match the new pacing."
                : "Affects the scenario prompt only."
            }
            icon={<MessageSquare className="h-3.5 w-3.5" />}
            title="Reply length"
          >
            {MESSAGE_LENGTHS.map((len) => {
              const meta = MESSAGE_LENGTH_META[len];
              return (
                <OptionPill
                  active={draftLength === len}
                  badgeColor={meta.color}
                  busy={busy}
                  isStored={storedLength === len}
                  key={len}
                  label={meta.label}
                  onClick={() => setDraftLength(len)}
                  sublabel={`${meta.sentenceRange} sentences`}
                />
              );
            })}
          </Section>

          <Section
            description={
              difficultyChanged
                ? "Will rebuild mood axes, difficulty profile, intimacy profile, and scenario."
                : "Changing this regenerates mood + scenario."
            }
            icon={<Shield className="h-3.5 w-3.5" />}
            title="Difficulty"
          >
            {DIFFICULTIES.map((d) => {
              const meta = DIFFICULTY_META[d];
              return (
                <OptionPill
                  active={draftDifficulty === d}
                  badgeColor={meta.color}
                  busy={busy}
                  isStored={storedDifficulty === d}
                  key={d}
                  label={meta.label}
                  onClick={() => setDraftDifficulty(d)}
                />
              );
            })}
          </Section>

          <Section
            description={
              modelChanged
                ? `Will rewrite all ${data.scenes.length || ""} scene prompts in the new model's format.`
                : "Switching the model rewrites every scene prompt."
            }
            icon={<Palette className="h-3.5 w-3.5" />}
            title="Image model"
          >
            {IMAGE_MODELS.map((m) => {
              const meta = IMAGE_MODEL_META[m];
              return (
                <OptionPill
                  active={draftModel === m}
                  badgeColor={meta.color}
                  busy={busy}
                  isStored={storedModel === m}
                  key={m}
                  label={meta.label}
                  onClick={() => setDraftModel(m)}
                />
              );
            })}
          </Section>
        </div>

        {busy && (
          <div className="flex items-center gap-2.5 rounded-lg border border-primary/30 bg-primary/5 px-3 py-2.5 text-primary text-xs">
            <Loader2 className="h-3.5 w-3.5 animate-spin" />
            <span>{STAGE_LABEL[stage as Exclude<RunStage, "idle">]}</span>
          </div>
        )}

        {!busy && hasChanges && (
          <PendingSummary
            difficultyChanged={difficultyChanged}
            lengthChanged={lengthChanged}
            modelChanged={modelChanged}
          />
        )}

        {error && (
          <p className="text-destructive text-xs leading-relaxed">{error}</p>
        )}

        <DialogFooter>
          <DialogClose
            disabled={busy}
            render={<Button disabled={busy} size="sm" variant="outline" />}
          >
            Cancel
          </DialogClose>
          <Button
            disabled={!hasChanges || busy}
            onClick={() => void handleSubmit()}
            size="sm"
          >
            {busy && <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" />}
            {busy ? "Regenerating…" : "Submit & regenerate"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function PendingSummary({
  difficultyChanged,
  lengthChanged,
  modelChanged,
}: {
  difficultyChanged: boolean;
  lengthChanged: boolean;
  modelChanged: boolean;
}) {
  const items: string[] = [];
  if (lengthChanged) items.push("re-run scenario");
  if (difficultyChanged) items.push("rebuild mood + intimacy + scenario");
  if (modelChanged) items.push("regenerate all scenes");

  return (
    <div className="rounded-lg border border-amber-500/30 bg-amber-500/5 px-3 py-2 text-amber-300/80 text-xs leading-relaxed">
      <span className="font-medium">On submit:</span> {items.join(" → ")}.
    </div>
  );
}

function Section({
  children,
  description,
  icon,
  title,
}: {
  children: React.ReactNode;
  description: string;
  icon: React.ReactNode;
  title: string;
}) {
  return (
    <div>
      <div className="mb-1.5 flex items-center gap-1.5 font-medium text-muted-foreground text-xs uppercase tracking-wider">
        <span className="text-foreground/60">{icon}</span>
        {title}
      </div>
      <div className="flex flex-wrap gap-1.5">{children}</div>
      <p className="mt-1.5 text-[11px] text-muted-foreground leading-snug">
        {description}
      </p>
    </div>
  );
}

function OptionPill({
  active,
  badgeColor,
  busy,
  isStored,
  label,
  onClick,
  sublabel,
}: {
  active: boolean;
  badgeColor: string;
  busy: boolean;
  isStored: boolean;
  label: string;
  onClick: () => void;
  sublabel?: string;
}) {
  return (
    <button
      aria-pressed={active}
      className={cn(
        "group/pill flex items-center gap-1.5 rounded-full border px-2.5 py-1 font-medium text-xs transition-all",
        active
          ? cn("border-transparent ring-1 ring-primary/40", badgeColor)
          : "border-white/8 bg-white/3 text-muted-foreground hover:border-white/15 hover:bg-white/5 hover:text-foreground",
        busy && "pointer-events-none opacity-50"
      )}
      disabled={busy}
      onClick={onClick}
      type="button"
    >
      <span>{label}</span>
      {sublabel && (
        <span
          className={cn(
            "text-[10px] font-normal",
            active ? "opacity-70" : "text-muted-foreground/60"
          )}
        >
          {sublabel}
        </span>
      )}
      {isStored && !active && (
        <span className="text-[9px] uppercase tracking-wider text-muted-foreground/50">
          current
        </span>
      )}
    </button>
  );
}
