import { Bot, ImagePlus, Loader2, MessageSquare, Sparkles } from "lucide-react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { ChatContainer } from "@/components/chat/chat-container";
import { ChatInput } from "@/components/chat/chat-input";
import { ChatMessage } from "@/components/chat/chat-message";
import { AutopilotPill } from "@/components/chrome/autopilot-pill";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useAgentChat } from "@/hooks/use-agent-chat";
import { useChatAutopilot } from "@/hooks/use-chat-autopilot";
import { getFullName, getStoredImageModel, type StoredCharacter } from "@/lib/types";
import { serializeTranscriptForReplay } from "@shared/chat-replay";

interface AddSceneDialogProps {
  character: StoredCharacter;
  onOpenChange: (open: boolean) => void;
  onSceneAdded?: (updated: StoredCharacter) => void;
  open: boolean;
}

export function AddSceneDialog({
  character,
  onOpenChange,
  onSceneAdded,
  open,
}: AddSceneDialogProps) {
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const chat = useAgentChat();
  const prevOpenRef = useRef(open);
  const [autopilot, setAutopilot] = useState(false);

  useChatAutopilot({
    enabled: autopilot,
    messages: chat.messages,
    addToolOutput: chat.addToolOutput,
  });

  useEffect(() => {
    if (prevOpenRef.current && !open) {
      void chat.stop();
      chat.setMessages([]);
      setGenerating(false);
      setError(null);
      setAutopilot(false);
    }
    prevOpenRef.current = open;
  }, [open, chat]);

  const isStreaming = chat.status === "streaming" || chat.status === "submitted";
  const showGenerate =
    chat.messages.length > 1 &&
    !isStreaming &&
    !generating &&
    chat.status !== "error";

  const gatheringSummary = useMemo(
    () => chat.finalSummary ?? serializeTranscriptForReplay(chat.messages),
    [chat.finalSummary, chat.messages]
  );

  const handleSend = useCallback(
    async (text: string) => {
      setError(null);
      if (chat.sessionId) {
        await chat.sendMessage({ text });
      } else {
        await chat.start({
          flow: "gather-scene",
          character: character.character,
          existingScenes: character.scenes,
          initialUserMessage: text,
        });
      }
    },
    [chat, character]
  );

  const handleGenerate = useCallback(async () => {
    setGenerating(true);
    setError(null);
    try {
      const result = await window.api.generate.sceneSingle({
        runId: `scene-single-${Date.now()}`,
        character: character.character,
        existingScenes: character.scenes,
        gatheringSummary,
        imageModel: getStoredImageModel(character),
      });
      if (!result.success) {
        setError(result.error);
        return;
      }
      const updated = await window.api.characters.appendScene(
        character.id,
        result.scene
      );
      if (updated) {
        onSceneAdded?.(updated);
      }
      onOpenChange(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setGenerating(false);
    }
  }, [character, gatheringSummary, onOpenChange, onSceneAdded]);

  return (
    <Dialog onOpenChange={onOpenChange} open={open}>
      <DialogContent
        className="flex h-[80vh] max-w-2xl flex-col gap-0 overflow-hidden p-0 sm:max-w-2xl"
        showCloseButton
      >
        <DialogHeader className="border-white/6 border-b px-5 py-4">
          <div className="flex items-center justify-between gap-3 pr-8">
            <DialogTitle className="flex items-center gap-2">
              <ImagePlus className="h-4 w-4 text-primary" />
              Add Scene
            </DialogTitle>
            <AutopilotPill
              disabled={generating}
              enabled={autopilot}
              onToggle={setAutopilot}
            />
          </div>
        </DialogHeader>

        <ChatContainer>
          <div className="flex w-full flex-col gap-4">
            {chat.messages.length === 0 && (
              <div className="flex flex-col items-center py-12 text-center">
                <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/10">
                  <MessageSquare className="h-5 w-5 text-primary" />
                </div>
                <p className="mb-1 font-medium text-sm">
                  Describe the scene you want
                </p>
                <p className="max-w-sm text-muted-foreground text-xs leading-relaxed">
                  Type a scene description, or ask the AI to suggest ideas for{" "}
                  {getFullName(character.character)}.
                </p>
              </div>
            )}
            {chat.messages.map((msg) => (
              <ChatMessage
                addToolOutput={chat.addToolOutput}
                key={msg.id}
                message={msg}
                onDelete={!isStreaming ? chat.deleteMessage : undefined}
                onEdit={!isStreaming ? chat.editAndResend : undefined}
                onRegenerateFrom={!isStreaming ? chat.regenerateFrom : undefined}
              />
            ))}

            {chat.status === "submitted" && (
              <div className="flex animate-message-in gap-3">
                <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-white/6 text-muted-foreground">
                  <Bot className="h-3.5 w-3.5" />
                </div>
                <div className="flex items-center gap-2.5 rounded-2xl rounded-tl-md bg-white/5 px-4 py-3">
                  <div className="flex items-center gap-1">
                    <span className="h-1.5 w-1.5 animate-thinking-dot rounded-full bg-primary/70" />
                    <span className="h-1.5 w-1.5 animate-thinking-dot rounded-full bg-primary/70 [animation-delay:200ms]" />
                    <span className="h-1.5 w-1.5 animate-thinking-dot rounded-full bg-primary/70 [animation-delay:400ms]" />
                  </div>
                  <span className="text-muted-foreground text-xs">Thinking...</span>
                </div>
              </div>
            )}

            {generating && (
              <div className="flex animate-message-in items-center justify-center gap-3 py-10">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10">
                  <Loader2 className="h-4 w-4 animate-spin text-primary" />
                </div>
                <div className="flex flex-col gap-1">
                  <span className="font-medium text-foreground text-sm">
                    Generating scene prompt
                  </span>
                  <div className="h-1.5 w-40 overflow-hidden rounded-full bg-white/5">
                    <div className="h-full w-full animate-shimmer rounded-full" />
                  </div>
                </div>
              </div>
            )}

            {error && (
              <div className="rounded-lg border border-destructive/40 bg-destructive/10 px-3 py-2 text-destructive text-xs">
                {error}
              </div>
            )}
          </div>
        </ChatContainer>

        <div className="border-white/6 border-t bg-background/80 backdrop-blur-xl">
          <div className="space-y-3 px-5 py-3">
            {showGenerate && (
              <Button
                className="glow-sm w-full"
                disabled={generating}
                onClick={handleGenerate}
              >
                <Sparkles className="mr-2 h-4 w-4" />
                Generate Scene Prompt
              </Button>
            )}
            {!generating && (
              <ChatInput
                disabled={isStreaming || generating}
                onSend={(text) => void handleSend(text)}
                placeholder="Describe the scene you want..."
              />
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
