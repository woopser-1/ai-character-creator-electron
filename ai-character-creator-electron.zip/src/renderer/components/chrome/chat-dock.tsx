import { AnimatePresence, motion } from "motion/react";
import type { ReactNode } from "react";
import { ChatInput } from "@/components/chat/chat-input";

interface ChatDockProps {
  onSend: (text: string) => void;
  placeholder?: string;
  disabled?: boolean;
  extraAbove?: ReactNode;
}

export function ChatDock({ onSend, placeholder, disabled, extraAbove }: ChatDockProps) {
  return (
    <motion.div
      animate={{ y: 0, opacity: 1 }}
      className="relative border-white/6 border-t bg-background/80 backdrop-blur-xl"
      initial={{ y: 12, opacity: 0 }}
      transition={{ type: "spring", stiffness: 320, damping: 30 }}
    >
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-primary/25 to-transparent" />
      <motion.div
        className="mx-auto w-full max-w-3xl px-4 py-2.5 sm:px-6"
        layout="position"
        transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
      >
        <AnimatePresence initial={false} mode="popLayout">
          {extraAbove && (
            <motion.div
              animate={{ height: "auto", opacity: 1 }}
              className="overflow-hidden"
              exit={{ height: 0, opacity: 0 }}
              initial={{ height: 0, opacity: 0 }}
              key="extra"
              transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
            >
              <div className="pb-2.5">{extraAbove}</div>
            </motion.div>
          )}
        </AnimatePresence>
        <ChatInput disabled={disabled} onSend={onSend} placeholder={placeholder} />
      </motion.div>
    </motion.div>
  );
}
