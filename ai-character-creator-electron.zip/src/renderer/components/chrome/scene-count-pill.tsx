import { Popover } from "@base-ui/react/popover";
import { Check, Image as ImageIcon } from "lucide-react";
import { SCENE_COUNT_OPTIONS } from "@/lib/types";
import { cn } from "@/lib/utils";

interface SceneCountPillProps {
  value: number;
  onChange?: (next: number) => void;
  readOnly?: boolean;
}

const PILL_COLOR = "text-teal-400 bg-teal-500/15";

export function SceneCountPill({ value, onChange, readOnly }: SceneCountPillProps) {
  if (readOnly || !onChange) {
    return (
      <div
        className={cn(
          "flex items-center gap-1 rounded-full px-2.5 py-1 font-medium text-xs",
          PILL_COLOR
        )}
      >
        <ImageIcon className="h-3 w-3" />
        {value} scenes
      </div>
    );
  }

  return (
    <Popover.Root>
      <Popover.Trigger
        className={cn(
          "flex items-center gap-1 rounded-full px-2.5 py-1 font-medium text-xs outline-none ring-1 ring-transparent transition-all hover:brightness-125 focus-visible:ring-primary/40",
          PILL_COLOR
        )}
      >
        <ImageIcon className="h-3 w-3" />
        {value} scenes
      </Popover.Trigger>
      <Popover.Portal>
        <Popover.Positioner align="end" sideOffset={8}>
          <Popover.Popup className="origin-top-right data-[ending-style]:opacity-0 data-[starting-style]:opacity-0 data-[ending-style]:scale-[0.96] data-[starting-style]:scale-[0.96] transition-all duration-150 ease-out">
            <div className="w-56 rounded-xl border border-white/8 bg-popover/95 p-1.5 shadow-2xl backdrop-blur-2xl">
              <div className="px-2 pt-1 pb-2 font-medium text-[10px] text-muted-foreground uppercase tracking-wider">
                Number of scenes
              </div>
              {SCENE_COUNT_OPTIONS.map((n) => {
                const selected = n === value;
                return (
                  <Popover.Close
                    className={cn(
                      "flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-left transition-colors hover:bg-white/5",
                      selected && "bg-white/5"
                    )}
                    key={n}
                    onClick={() => onChange(n)}
                  >
                    <div
                      className={cn(
                        "flex h-4 w-4 shrink-0 items-center justify-center rounded-full",
                        PILL_COLOR
                      )}
                    >
                      {selected && <Check className="h-2.5 w-2.5" strokeWidth={3} />}
                    </div>
                    <div className="flex-1">
                      <div className={cn("font-medium text-xs", selected && "text-foreground")}>
                        {n} scenes
                      </div>
                    </div>
                  </Popover.Close>
                );
              })}
            </div>
          </Popover.Popup>
        </Popover.Positioner>
      </Popover.Portal>
    </Popover.Root>
  );
}
