import { AnimatePresence, motion } from "motion/react";
import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

interface SubHeaderProps {
  icon: ReactNode;
  title: string;
  /** Keyed for AnimatePresence phase swap. Defaults to the subtitle string itself. */
  subtitle: string;
  subtitleKey?: string;
  stepper?: ReactNode;
  actions?: ReactNode;
  className?: string;
}

export function SubHeader({
  icon,
  title,
  subtitle,
  subtitleKey,
  stepper,
  actions,
  className,
}: SubHeaderProps) {
  return (
    <motion.div
      animate={{ y: 0, opacity: 1 }}
      className={cn(
        "relative border-white/6 border-b bg-background/60 backdrop-blur-2xl",
        className
      )}
      initial={{ y: -6, opacity: 0 }}
      transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
    >
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent" />
      <div className="mx-auto flex max-w-5xl items-center justify-between gap-4 px-4 py-2.5 sm:px-6">
        <div className="flex min-w-0 items-center gap-3">
          <motion.div
            className="glow-sm flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-primary/15"
            transition={{ type: "spring", stiffness: 400, damping: 24 }}
            whileHover={{ rotate: -6, scale: 1.05 }}
          >
            {icon}
          </motion.div>
          <div className="min-w-0">
            <h1 className="truncate font-semibold text-sm tracking-tight">{title}</h1>
            <div className="relative h-4">
              <AnimatePresence initial={false} mode="wait">
                <motion.p
                  animate={{ opacity: 1, y: 0 }}
                  className="absolute inset-0 truncate text-muted-foreground text-xs"
                  exit={{ opacity: 0, y: -4 }}
                  initial={{ opacity: 0, y: 4 }}
                  key={subtitleKey ?? subtitle}
                  transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
                >
                  {subtitle}
                </motion.p>
              </AnimatePresence>
            </div>
          </div>
        </div>
        {stepper && <div className="hidden shrink-0 md:block">{stepper}</div>}
        {actions && <div className="flex shrink-0 items-center gap-2">{actions}</div>}
      </div>
    </motion.div>
  );
}
