import { Popover } from "@base-ui/react/popover";
import { Check, Shield } from "lucide-react";
import { DIFFICULTIES, DIFFICULTY_META, type Difficulty } from "@/lib/types";
import { cn } from "@/lib/utils";

interface DifficultyPillProps {
  value: Difficulty;
  onChange?: (next: Difficulty) => void;
  readOnly?: boolean;
}

export function DifficultyPill({ value, onChange, readOnly }: DifficultyPillProps) {
  const meta = DIFFICULTY_META[value];

  if (readOnly || !onChange) {
    return (
      <div
        className={cn(
          "flex items-center gap-1 rounded-full px-2.5 py-1 font-medium text-xs",
          meta.color
        )}
      >
        <Shield className="h-3 w-3" />
        {meta.label}
      </div>
    );
  }

  return (
    <Popover.Root>
      <Popover.Trigger
        className={cn(
          "flex items-center gap-1 rounded-full px-2.5 py-1 font-medium text-xs outline-none ring-1 ring-transparent transition-all hover:brightness-125 focus-visible:ring-primary/40",
          meta.color
        )}
      >
        <Shield className="h-3 w-3" />
        {meta.label}
      </Popover.Trigger>
      <Popover.Portal>
        <Popover.Positioner align="end" sideOffset={8}>
          <Popover.Popup className="origin-top-right data-[ending-style]:opacity-0 data-[starting-style]:opacity-0 data-[ending-style]:scale-[0.96] data-[starting-style]:scale-[0.96] transition-all duration-150 ease-out">
            <div className="w-64 rounded-xl border border-white/8 bg-popover/95 p-1.5 shadow-2xl backdrop-blur-2xl">
              <div className="px-2 pt-1 pb-2 font-medium text-[10px] text-muted-foreground uppercase tracking-wider">
                Chat Difficulty
              </div>
              {DIFFICULTIES.map((d) => {
                const m = DIFFICULTY_META[d];
                const selected = d === value;
                return (
                  <Popover.Close
                    className={cn(
                      "flex w-full items-start gap-2 rounded-lg px-2.5 py-2 text-left transition-colors hover:bg-white/5",
                      selected && "bg-white/5"
                    )}
                    key={d}
                    onClick={() => onChange(d)}
                  >
                    <div
                      className={cn(
                        "mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full",
                        m.color
                      )}
                    >
                      {selected && <Check className="h-2.5 w-2.5" strokeWidth={3} />}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className={cn("font-medium text-xs", selected && "text-foreground")}>
                        {m.label}
                      </div>
                      <div className="mt-0.5 text-[11px] text-muted-foreground leading-snug">
                        {m.description}
                      </div>
                    </div>
                  </Popover.Close>
                );
              })}
            </div>
          </Popover.Popup>
        </Popover.Positioner>
      </Popover.Portal>
    </Popover.Root>
  );
}
