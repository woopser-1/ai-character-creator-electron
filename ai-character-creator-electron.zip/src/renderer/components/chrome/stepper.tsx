import { Check } from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { cn } from "@/lib/utils";

export interface StepperStep {
  id: string;
  label: string;
}

interface StepperProps {
  steps: StepperStep[];
  activeIndex: number;
  doneCount: number;
}

export function Stepper({ steps, activeIndex, doneCount }: StepperProps) {
  return (
    <div className="relative flex items-center gap-1.5">
      {steps.map((step, i) => {
        const done = i < doneCount;
        const active = i === activeIndex && !done;
        return (
          <div className="flex items-center gap-1.5" key={step.id}>
            <motion.div
              animate={{ scale: 1, opacity: 1 }}
              className={cn(
                "relative flex items-center gap-1.5 rounded-full px-2.5 py-1 font-medium text-xs",
                done
                  ? "bg-emerald-500/15 text-emerald-400"
                  : active
                    ? "text-primary"
                    : "bg-muted/50 text-muted-foreground"
              )}
              initial={{ scale: 0.95, opacity: 0 }}
              transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
            >
              {active && (
                <motion.div
                  className="-z-0 absolute inset-0 rounded-full bg-primary/15 ring-1 ring-primary/30"
                  layoutId="stepper-active-pill"
                  transition={{ type: "spring", stiffness: 420, damping: 32 }}
                />
              )}
              <span
                className={cn(
                  "relative z-10 flex h-4 w-4 items-center justify-center rounded-full font-bold text-[10px]",
                  done
                    ? "bg-emerald-500/25 text-emerald-400"
                    : active
                      ? "bg-primary/25 text-primary"
                      : "bg-muted text-muted-foreground"
                )}
              >
                <AnimatePresence initial={false} mode="wait">
                  {done ? (
                    <motion.span
                      animate={{ scale: 1, opacity: 1 }}
                      exit={{ scale: 0.5, opacity: 0 }}
                      initial={{ scale: 0.5, opacity: 0 }}
                      key="check"
                      transition={{ type: "spring", stiffness: 500, damping: 22 }}
                    >
                      <Check className="h-2.5 w-2.5" strokeWidth={3} />
                    </motion.span>
                  ) : (
                    <motion.span
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      initial={{ opacity: 0 }}
                      key="num"
                    >
                      {i + 1}
                    </motion.span>
                  )}
                </AnimatePresence>
              </span>
              <span className="relative z-10">{step.label}</span>
            </motion.div>
            {i < steps.length - 1 && (
              <div className="relative h-[2px] w-6 overflow-hidden rounded-full bg-muted/40">
                <motion.div
                  animate={{ scaleX: done ? 1 : 0 }}
                  className="h-full origin-left rounded-full bg-emerald-500/50"
                  initial={{ scaleX: 0 }}
                  transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
                />
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
