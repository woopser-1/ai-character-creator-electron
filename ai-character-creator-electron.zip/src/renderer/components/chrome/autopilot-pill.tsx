import { Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

interface AutopilotPillProps {
  enabled: boolean;
  onToggle: (next: boolean) => void;
  disabled?: boolean;
}

const PILL_BASE =
  "flex items-center gap-1 rounded-full px-2.5 py-1 font-medium text-xs outline-none ring-1 ring-transparent transition-all hover:brightness-125 focus-visible:ring-primary/40 disabled:cursor-not-allowed disabled:opacity-50";

export function AutopilotPill({
  enabled,
  onToggle,
  disabled,
}: AutopilotPillProps) {
  return (
    <button
      aria-pressed={enabled}
      className={cn(
        PILL_BASE,
        enabled
          ? "glow-sm bg-primary/20 text-primary"
          : "bg-white/5 text-muted-foreground"
      )}
      disabled={disabled}
      onClick={() => onToggle(!enabled)}
      title={
        enabled
          ? "Autopilot is on — the AI answers every question for you"
          : "Turn on Autopilot to let the AI answer every question"
      }
      type="button"
    >
      <Sparkles className="h-3 w-3" />
      Autopilot{enabled ? " · On" : ""}
    </button>
  );
}
