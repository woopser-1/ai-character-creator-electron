import { AlertTriangle, Check, ChevronDown, ChevronRight, Copy, KeyRound, Loader2, RefreshCw, ShieldAlert } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import type { GenerateStepId, StepUsage } from "@shared/generate";

export interface StepState {
  id: GenerateStepId;
  label: string;
  status: "idle" | "running" | "succeeded" | "failed" | "refusal-detected";
  error?: string;
  usage?: StepUsage;
  adminOverrideApplied?: boolean;
}

export interface GenerationStepsProps {
  steps: StepState[];
  superAdmin: boolean;
  onRetry?: (stepId: GenerateStepId) => void;
  title?: string;
}

function formatTokens(n: number): string {
  if (n < 1000) return `${n}`;
  if (n < 10000) return `${(n / 1000).toFixed(1)}k`;
  return `${Math.round(n / 1000)}k`;
}

function formatUsd(n: number): string {
  if (n === 0) return "$0";
  if (n < 0.01) return `$${n.toFixed(4)}`;
  if (n < 1) return `$${n.toFixed(3)}`;
  return `$${n.toFixed(2)}`;
}

function formatDuration(ms: number): string {
  if (ms < 1000) return `${ms}ms`;
  return `${(ms / 1000).toFixed(1)}s`;
}

function totalTokens(usage: StepUsage): number {
  return usage.inputTokens + usage.outputTokens + usage.cacheReadTokens;
}

export function GenerationSteps({ steps, superAdmin, onRetry, title }: GenerationStepsProps) {
  const totals = steps.reduce(
    (acc, s) => {
      if (!s.usage) return acc;
      return {
        tokens: acc.tokens + totalTokens(s.usage),
        costUsd: acc.costUsd + s.usage.costUsd,
      };
    },
    { tokens: 0, costUsd: 0 }
  );

  const hasRefusal = steps.some((s) => s.status === "refusal-detected" || (s.status === "failed" && s.error?.toLowerCase().includes("refus")));

  return (
    <div className="animate-message-in rounded-xl border border-white/6 bg-white/2 p-4">
      {title && (
        <p className="mb-3 font-medium text-sm tracking-tight">{title}</p>
      )}
      <ul className="space-y-2">
        {steps.map((step) => (
          <li
            key={step.id}
            className="flex items-center gap-3 rounded-lg border border-white/5 bg-white/2 px-3 py-2"
          >
            <StepIcon status={step.status} />
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <span className="font-medium text-sm">{step.label}</span>
                {step.adminOverrideApplied && (
                  <span className="flex items-center gap-1 rounded-full bg-amber-500/15 px-1.5 py-0.5 font-medium text-[10px] text-amber-400">
                    <ShieldAlert className="h-2.5 w-2.5" />
                    override
                  </span>
                )}
              </div>
              {(step.status === "failed" || step.status === "refusal-detected") && step.error && (
                <StepErrorBlock error={step.error} refusal={step.status === "refusal-detected"} superAdmin={superAdmin} />
              )}
            </div>
            {step.usage && (
              <div className="hidden flex-col items-end gap-0.5 text-right text-muted-foreground text-[11px] sm:flex"
                title={`in ${step.usage.inputTokens} · out ${step.usage.outputTokens} · cache-read ${step.usage.cacheReadTokens} · cache-create ${step.usage.cacheCreationTokens}`}
              >
                <span className="font-mono">
                  {formatTokens(totalTokens(step.usage))} tok · {formatUsd(step.usage.costUsd)}
                </span>
                <span className="font-mono text-muted-foreground/70">
                  {formatDuration(step.usage.durationMs)} · {step.usage.model}
                </span>
              </div>
            )}
            {(step.status === "failed" || step.status === "refusal-detected") && onRetry && (
              <Button
                onClick={() => onRetry(step.id)}
                size="icon-sm"
                title="Retry this step"
                variant="ghost"
              >
                <RefreshCw className="h-3.5 w-3.5" />
              </Button>
            )}
          </li>
        ))}
      </ul>
      <div className="mt-3 flex items-center justify-between border-white/5 border-t pt-3">
        <span className="text-muted-foreground text-xs">
          {hasRefusal && !superAdmin ? (
            <span className="text-amber-400/90">
              At least one step was refused. Enable Super Admin mode to force generation.
            </span>
          ) : (
            "Total consumed"
          )}
        </span>
        <span className="font-mono text-xs">
          {formatTokens(totals.tokens)} tok · {formatUsd(totals.costUsd)}
        </span>
      </div>
    </div>
  );
}

function StepErrorBlock({
  error,
  refusal,
  superAdmin,
}: {
  error: string;
  refusal: boolean;
  superAdmin: boolean;
}) {
  const [expanded, setExpanded] = useState(false);
  const [copied, setCopied] = useState(false);
  const isAuth = error.includes("AUTH:") || error.includes("ClaudeAuthError") || error.includes("not authenticated");
  const firstLine = error.split("\n")[0].slice(0, 200);

  const handleCopy = () => {
    void navigator.clipboard
      .writeText(error)
      .then(() => {
        setCopied(true);
        setTimeout(() => setCopied(false), 1600);
      })
      .catch(() => {
        /* ignore */
      });
  };

  if (isAuth) {
    return (
      <div className="mt-1 animate-in fade-in rounded-md border border-red-500/30 bg-red-500/8 px-2.5 py-1.5 text-xs text-red-200 duration-200">
        <div className="flex items-center gap-1.5">
          <KeyRound className="h-3 w-3 shrink-0" />
          <span className="font-medium">Claude Code is not authenticated.</span>
          <code className="rounded bg-red-950/40 px-1 py-0.5 font-mono text-[11px]">claude login</code>
          <a className="ml-auto underline hover:text-red-100" href="#/settings">
            How to fix
          </a>
        </div>
        <button
          className="mt-1 text-[11px] text-red-300/70 underline hover:text-red-200"
          onClick={() => setExpanded((v) => !v)}
          type="button"
        >
          {expanded ? "Hide details" : "Show raw error"}
        </button>
        {expanded && (
          <pre className="mt-1 max-h-48 overflow-auto whitespace-pre-wrap break-all rounded bg-black/30 p-2 font-mono text-[11px] text-red-200/80">
            {error}
          </pre>
        )}
      </div>
    );
  }

  const tone = refusal
    ? "border-amber-500/30 bg-amber-500/8 text-amber-200"
    : "border-red-500/30 bg-red-500/8 text-red-200";
  const label = refusal ? "Refusal detected" : "Generation failed";

  return (
    <div className={`mt-1 animate-in fade-in rounded-md border px-2.5 py-1.5 text-xs duration-200 ${tone}`}>
      <button
        className="flex w-full items-center gap-1.5 text-left"
        onClick={() => setExpanded((v) => !v)}
        type="button"
      >
        {expanded ? (
          <ChevronDown className="h-3 w-3 shrink-0" />
        ) : (
          <ChevronRight className="h-3 w-3 shrink-0" />
        )}
        <span className="font-medium">{label}:</span>
        <span className="min-w-0 truncate opacity-80" title={firstLine}>
          {firstLine}
        </span>
        <span
          aria-label="Copy error"
          className="ml-auto inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-[10px] opacity-70 hover:bg-white/5 hover:opacity-100"
          onClick={(e) => {
            e.stopPropagation();
            handleCopy();
          }}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === " ") {
              e.stopPropagation();
              handleCopy();
            }
          }}
        >
          {copied ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
          {copied ? "Copied" : "Copy"}
        </span>
      </button>
      {expanded && (
        <pre className="mt-1.5 max-h-64 overflow-auto whitespace-pre-wrap break-all rounded bg-black/30 p-2 font-mono text-[11px] opacity-90">
          {error}
        </pre>
      )}
      {refusal && !superAdmin && (
        <p className="mt-1 text-[11px] opacity-80">
          <a className="underline hover:opacity-100" href="#/settings">
            Enable Super Admin mode
          </a>{" "}
          to force generation.
        </p>
      )}
    </div>
  );
}

function StepIcon({ status }: { status: StepState["status"] }) {
  if (status === "running") {
    return (
      <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/15">
        <Loader2 className="h-3.5 w-3.5 animate-spin text-primary" />
      </div>
    );
  }
  if (status === "succeeded") {
    return (
      <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-emerald-500/15 text-emerald-400">
        <Check className="h-3.5 w-3.5" />
      </div>
    );
  }
  if (status === "failed") {
    return (
      <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-500/15 text-red-400">
        <AlertTriangle className="h-3.5 w-3.5" />
      </div>
    );
  }
  if (status === "refusal-detected") {
    return (
      <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-amber-500/15 text-amber-400">
        <ShieldAlert className="h-3.5 w-3.5" />
      </div>
    );
  }
  return (
    <div className="h-6 w-6 shrink-0 rounded-full border border-white/10 bg-white/2" />
  );
}
