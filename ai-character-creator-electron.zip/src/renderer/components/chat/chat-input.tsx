
import { ArrowUp } from "lucide-react"
import { type KeyboardEvent, useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"

interface ChatInputProps {
  disabled?: boolean
  onSend: (message: string) => void
  placeholder?: string
}

export function ChatInput({
  onSend,
  disabled,
  placeholder = "Describe your character concept...",
}: ChatInputProps) {
  const [value, setValue] = useState("")

  function handleSend() {
    if (!value.trim() || disabled) {
      return
    }
    onSend(value.trim())
    setValue("")
  }

  function handleKeyDown(e: KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  return (
    <div className="relative flex items-end gap-2 rounded-xl border border-white/8 bg-white/3 p-1.5 transition-colors focus-within:border-primary/30 focus-within:bg-white/5">
      <Textarea
        className="min-h-[44px] flex-1 resize-none border-0 bg-transparent px-3 py-2.5 text-sm shadow-none ring-0 placeholder:text-muted-foreground/60 focus-visible:ring-0"
        disabled={disabled}
        onChange={(e) => setValue(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder={placeholder}
        rows={1}
        value={value}
      />
      <Button
        className="h-8 w-8 shrink-0 rounded-lg"
        disabled={!value.trim() || disabled}
        onClick={handleSend}
        size="icon"
      >
        <ArrowUp className="h-4 w-4" />
      </Button>
    </div>
  )
}
