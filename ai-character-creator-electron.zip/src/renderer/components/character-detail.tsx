import {
  BookOpen,
  Brain,
  Eye,
  Gauge,
  Heart,
  Image,
  MessageSquare,
  Palette,
  Shield,
  Sparkles,
  Tag,
  User,
} from "lucide-react"
import { CopyButton } from "@/components/copy-button"
import { Badge } from "@/components/ui/badge"
import { CollapsibleField } from "@/components/ui/collapsible-field"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useCopyToClipboard } from "@/hooks/use-copy-to-clipboard"
import type { Measurements, MoodAxis, StoredCharacter } from "@/lib/types"
import {
  DIFFICULTY_META,
  getFullName,
  getStoredImageModel,
  IMAGE_MODEL_META,
  MESSAGE_LENGTH_META,
} from "@/lib/types"
import { cn } from "@/lib/utils"

interface CharacterDetailProps {
  data: StoredCharacter
}

function Field({
  label,
  value,
  icon,
  mono,
}: {
  label: string
  value: string
  icon?: React.ReactNode
  mono?: boolean
}) {
  const { copied, copy } = useCopyToClipboard()

  return (
    <div className="group">
      {label && (
        <div className="mb-2 flex items-center justify-between">
          <div className="flex items-center gap-1.5 font-medium text-[10.5px] text-muted-foreground uppercase tracking-[0.15em]">
            {icon}
            {label}
            {copied && (
              <span className="font-medium text-[10px] text-emerald-400 normal-case tracking-normal">
                Copied
              </span>
            )}
          </div>
          <CopyButton
            className="opacity-0 transition-opacity group-hover:opacity-100"
            value={value}
          />
        </div>
      )}
      <button
        aria-label={`Copy ${label || "value"}`}
        className={cn(
          "block w-full cursor-pointer whitespace-pre-wrap text-left text-sm leading-relaxed transition-all",
          mono
            ? "rounded-xl border border-white/8 bg-black/30 p-3.5 font-mono text-[12px] text-foreground/90 leading-relaxed shadow-inner shadow-black/20 hover:border-white/12 hover:bg-black/40"
            : "-mx-1.5 rounded-md px-1.5 py-0.5 hover:bg-white/5",
          copied && "ring-1 ring-emerald-500/40"
        )}
        onClick={() => void copy(value)}
        type="button"
      >
        {value}
      </button>
    </div>
  )
}

function Section({
  title,
  icon,
  children,
}: {
  title: string
  icon: React.ReactNode
  children: React.ReactNode
}) {
  return (
    <section>
      <div className="mb-3 flex items-center gap-2.5">
        <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary/10 text-primary ring-1 ring-primary/20">
          {icon}
        </span>
        <h2 className="font-semibold text-foreground text-sm tracking-tight">
          {title}
        </h2>
      </div>
      <div className="rounded-2xl border border-white/6 bg-white/[0.018] p-5 shadow-[inset_0_1px_0_0_rgba(255,255,255,0.03)]">
        {children}
      </div>
    </section>
  )
}

const POST_INTIMACY_LABELS: Record<string, { label: string; color: string }> = {
  regretful: { label: "Regretful", color: "text-red-400 bg-red-500/15" },
  guilty: { label: "Guilty", color: "text-orange-400 bg-orange-500/15" },
  awkward: { label: "Awkward", color: "text-amber-400 bg-amber-500/15" },
  tender: { label: "Tender", color: "text-pink-400 bg-pink-500/15" },
  satisfied: {
    label: "Satisfied",
    color: "text-emerald-400 bg-emerald-500/15",
  },
  detached: { label: "Detached", color: "text-zinc-400 bg-zinc-500/15" },
  clingy: { label: "Clingy", color: "text-violet-400 bg-violet-500/15" },
  anxious: { label: "Anxious", color: "text-yellow-400 bg-yellow-500/15" },
  empowered: { label: "Empowered", color: "text-sky-400 bg-sky-500/15" },
  conflicted: {
    label: "Conflicted",
    color: "text-indigo-400 bg-indigo-500/15",
  },
}

function DifficultyMeter({
  label,
  value,
  reasoning,
}: {
  label: string
  value: number
  reasoning: string
}) {
  const percentage = (value / 10) * 100
  const gradient =
    value <= 3
      ? "from-emerald-500/80 to-emerald-400"
      : value <= 6
        ? "from-amber-500/80 to-amber-400"
        : value <= 8
          ? "from-orange-500/80 to-orange-400"
          : "from-red-500/80 to-red-400"

  return (
    <div>
      <div className="mb-2 flex items-baseline justify-between gap-2">
        <span className="font-medium text-[10.5px] text-muted-foreground uppercase tracking-[0.15em]">
          {label}
        </span>
        <span className="font-semibold text-foreground text-sm tabular-nums">
          {value}
          <span className="text-muted-foreground/60 text-xs"> / 10</span>
        </span>
      </div>
      <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/5">
        <div
          className={cn(
            "h-full rounded-full bg-gradient-to-r transition-all duration-500",
            gradient
          )}
          style={{ width: `${percentage}%` }}
        />
      </div>
      <p className="mt-2 text-muted-foreground text-xs leading-relaxed">
        {reasoning}
      </p>
    </div>
  )
}

function MoodAxisMeter({ axis }: { axis: MoodAxis }) {
  const pct = Math.max(0, Math.min(100, axis.startingValue))
  const gradient =
    pct < 25
      ? "from-red-500/80 to-red-400"
      : pct < 50
        ? "from-orange-500/80 to-orange-400"
        : pct < 75
          ? "from-amber-500/80 to-amber-400"
          : "from-emerald-500/80 to-emerald-400"

  return (
    <div>
      <div className="mb-2 flex items-baseline justify-between gap-2">
        <span className="font-medium text-[10.5px] text-muted-foreground uppercase tracking-[0.15em]">
          {axis.label}
        </span>
        <span className="font-semibold text-foreground text-sm tabular-nums">
          {axis.startingValue}
          <span className="text-muted-foreground/60 text-xs"> / 100</span>
        </span>
      </div>
      <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/5">
        <div
          className={cn(
            "h-full rounded-full bg-gradient-to-r transition-all duration-500",
            gradient
          )}
          style={{ width: `${pct}%` }}
        />
      </div>
      <div className="mt-1.5 flex items-center justify-between text-[10px] text-muted-foreground/70 uppercase tracking-[0.15em]">
        <span>0 · {axis.lowDescriptor}</span>
        <span>{axis.highDescriptor} · 100</span>
      </div>
      <p className="mt-2 text-muted-foreground text-xs leading-relaxed">
        {axis.reasoning}
      </p>
    </div>
  )
}

function MeasurementsGrid({ measurements }: { measurements: Measurements }) {
  const items: { label: string; value: string }[] = [
    { label: "Height", value: `${measurements.heightCm} cm` },
    { label: "Bust", value: `${measurements.bustCm} cm` },
    { label: "Cup", value: measurements.cupSize },
    { label: "Waist", value: `${measurements.waistCm} cm` },
    { label: "Hips", value: `${measurements.hipsCm} cm` },
  ]
  return (
    <div>
      <div className="mb-2.5 font-medium text-[10.5px] text-muted-foreground uppercase tracking-[0.15em]">
        Confirmed Measurements
      </div>
      <div className="grid grid-cols-2 overflow-hidden rounded-xl border border-white/8 bg-white/[0.03] sm:grid-cols-5 sm:divide-x sm:divide-white/6">
        {items.map((item) => (
          <div
            key={item.label}
            className="px-3 py-2.5 text-center"
          >
            <div className="text-[9.5px] text-muted-foreground/80 uppercase tracking-[0.15em]">
              {item.label}
            </div>
            <div className="mt-1 font-semibold text-foreground text-sm tabular-nums">
              {item.value}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

export function CharacterDetail({ data }: CharacterDetailProps) {
  const { character, scenes } = data
  const messageLengthMeta =
    data.messageLength && MESSAGE_LENGTH_META[data.messageLength]
  const imageModel = getStoredImageModel(data)
  const imageModelMeta = IMAGE_MODEL_META[imageModel]

  return (
    <div className="space-y-8">
      <div className="flex flex-col gap-6 sm:flex-row sm:gap-7">
        {data.profileImageUrl && (
          <div className="relative w-full shrink-0 sm:w-56 lg:w-64">
            <div
              aria-hidden
              className="-inset-3 absolute -z-10 rounded-[2rem] bg-gradient-to-br from-primary/20 via-fuchsia-500/10 to-transparent opacity-60 blur-2xl"
            />
            <img
              alt={getFullName(character)}
              className="aspect-[4/5] w-full rounded-3xl border border-white/10 object-cover shadow-2xl shadow-black/40 ring-1 ring-white/5"
              src={data.profileImageUrl}
            />
          </div>
        )}
        <div className="min-w-0 flex-1 sm:pt-1">
          <div className="font-medium text-[10.5px] text-muted-foreground/80 uppercase tracking-[0.22em]">
            Character Profile
          </div>
          <h1 className="mt-2 font-bold text-4xl tracking-tight sm:text-[2.65rem] sm:leading-[1.05]">
            {getFullName(character)}
          </h1>
          <p className="mt-2.5 text-muted-foreground text-sm">
            Created {new Date(data.createdAt).toLocaleDateString()}
          </p>

          <div className="mt-5 space-y-2">
            <div className="flex flex-wrap items-center gap-1.5">
              {data.difficulty && (
                <Badge
                  className={DIFFICULTY_META[data.difficulty].color}
                  variant="outline"
                >
                  <Shield className="mr-1 h-3 w-3" />
                  {DIFFICULTY_META[data.difficulty].label}
                </Badge>
              )}
              {messageLengthMeta && (
                <Badge className={messageLengthMeta.color} variant="outline">
                  <MessageSquare className="mr-1 h-3 w-3" />
                  {messageLengthMeta.label} ({messageLengthMeta.sentenceRange})
                </Badge>
              )}
              <Badge className={imageModelMeta.color} variant="outline">
                <Palette className="mr-1 h-3 w-3" />
                {imageModelMeta.label}
              </Badge>
            </div>
            <div className="flex flex-wrap items-center gap-1.5">
              <Badge variant="secondary">{character.personalityLabel}</Badge>
              <Badge variant="secondary">{character.occupationLabel}</Badge>
              <Badge variant="secondary">{character.relationshipLabel}</Badge>
              <Badge variant="secondary">{character.hobbyLabel}</Badge>
              <Badge variant="outline">{character.fetishLabel}</Badge>
            </div>
          </div>
        </div>
      </div>

      <Separator className="border-white/6" />

      <Tabs defaultValue="appearance">
        <TabsList>
          <TabsTrigger value="appearance">
            <User className="h-3.5 w-3.5" />
            Appearance
          </TabsTrigger>
          <TabsTrigger value="personality">
            <Brain className="h-3.5 w-3.5" />
            Personality
          </TabsTrigger>
          <TabsTrigger value="scenes">
            <Image className="h-3.5 w-3.5" />
            Scenes ({scenes.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="appearance">
          <div className="space-y-7">
            <Section
              icon={<Sparkles className="h-4 w-4" />}
              title="Base Generation Prompt"
            >
              <Field
                label="Generation Prompt"
                mono
                value={character.baseGenerationPrompt}
              />
            </Section>

            <Section
              icon={<User className="h-4 w-4" />}
              title="Body & Physical Details"
            >
              <div className="space-y-4">
                {character.confirmedMeasurements && (
                  <>
                    <MeasurementsGrid
                      measurements={character.confirmedMeasurements}
                    />
                    <Separator className="border-white/6" />
                  </>
                )}
                <CollapsibleField
                  label="Body & Physical Details"
                  value={character.customPhysicalDetails}
                />
              </div>
            </Section>

            <Section icon={<Eye className="h-4 w-4" />} title="Face Details">
              <CollapsibleField
                label="Face Details"
                value={character.customFaceDetails}
              />
            </Section>

            <Section
              icon={<Eye className="h-4 w-4" />}
              title="Public Description"
            >
              <CollapsibleField label="" value={character.publicDescription} />
            </Section>

            <Section
              icon={<Image className="h-4 w-4" />}
              title="Image Generation Prompt"
            >
              <Field
                label="Image Prompt"
                mono
                value={character.baseImagePrompt}
              />
            </Section>
          </div>
        </TabsContent>

        <TabsContent value="personality">
          <div className="space-y-7">
            <Section icon={<Tag className="h-4 w-4" />} title="Labels">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <Field label="Personality" value={character.personalityLabel} />
                <Field label="Occupation" value={character.occupationLabel} />
                <Field
                  label="Relationship Status"
                  value={character.relationshipLabel}
                />
                <Field label="Hobby" value={character.hobbyLabel} />
                <Field label="Fetish" value={character.fetishLabel} />
              </div>
            </Section>

            {character.moodAxes && (
              <Section
                icon={<Gauge className="h-4 w-4" />}
                title="Mood Axes (0-100)"
              >
                <div className="space-y-5">
                  <MoodAxisMeter axis={character.moodAxes.primary} />
                  <Separator className="border-white/6" />
                  <MoodAxisMeter axis={character.moodAxes.secondary} />
                </div>
              </Section>
            )}

            <Section
              icon={<MessageSquare className="h-4 w-4" />}
              title="Greeting"
            >
              <Field
                label="Greeting Message"
                mono
                value={character.greetingMessage}
              />
            </Section>

            <Section
              icon={<MessageSquare className="h-4 w-4" />}
              title="First Reply Suggestion"
            >
              <CollapsibleField
                label=""
                value={character.firstReplySuggestion}
              />
            </Section>

            <Section icon={<BookOpen className="h-4 w-4" />} title="Scenario">
              <CollapsibleField
                label="Scenario"
                mono
                value={character.scenario}
              />
            </Section>

            <Section
              icon={<Sparkles className="h-4 w-4" />}
              title="Personality & Background"
            >
              <div className="space-y-4">
                <CollapsibleField
                  label="Additional Personality Details"
                  value={character.additionalPersonalityDetails}
                />
                <Separator className="border-white/6" />
                <CollapsibleField
                  label="Extra Details"
                  value={character.extraDetails}
                />
              </div>
            </Section>

            <Section
              icon={<Brain className="h-4 w-4" />}
              title="Difficulty Profile"
            >
              <div className="space-y-5">
                <DifficultyMeter
                  label="Mood Resistance"
                  reasoning={character.difficultyProfile.moodResistanceReasoning}
                  value={character.difficultyProfile.moodResistance}
                />
                <Separator className="border-white/6" />
                <DifficultyMeter
                  label="Trust Threshold"
                  reasoning={character.difficultyProfile.trustThresholdReasoning}
                  value={character.difficultyProfile.trustThreshold}
                />
                <Separator className="border-white/6" />
                <DifficultyMeter
                  label="Personality Rigidity"
                  reasoning={
                    character.difficultyProfile.personalityRigidityReasoning
                  }
                  value={character.difficultyProfile.personalityRigidity}
                />
              </div>
            </Section>

            <Section
              icon={<Heart className="h-4 w-4" />}
              title="Intimacy Profile"
            >
              <div className="space-y-5">
                <DifficultyMeter
                  label="Escalation Speed"
                  reasoning={character.intimacyProfile.escalationSpeedReasoning}
                  value={character.intimacyProfile.escalationSpeed}
                />
                <Separator className="border-white/6" />
                <DifficultyMeter
                  label="Sexual Confidence"
                  reasoning={character.intimacyProfile.sexualConfidenceReasoning}
                  value={character.intimacyProfile.sexualConfidence}
                />
                <Separator className="border-white/6" />
                <DifficultyMeter
                  label="Emotional Detachment"
                  reasoning={
                    character.intimacyProfile.emotionalDetachmentReasoning
                  }
                  value={character.intimacyProfile.emotionalDetachment}
                />
                <Separator className="border-white/6" />
                <DifficultyMeter
                  label="Personality Consistency"
                  reasoning={
                    character.intimacyProfile.personalityConsistencyReasoning
                  }
                  value={character.intimacyProfile.personalityConsistency}
                />
                <Separator className="border-white/6" />
                <div>
                  <div className="mb-1.5 flex items-center justify-between">
                    <span className="font-medium text-muted-foreground text-xs uppercase tracking-wider">
                      Post-Intimacy Behavior
                    </span>
                    <Badge
                      className={
                        POST_INTIMACY_LABELS[
                          character.intimacyProfile.postIntimacyBehavior
                        ]?.color ?? "bg-zinc-500/15 text-zinc-400"
                      }
                      variant="outline"
                    >
                      {POST_INTIMACY_LABELS[
                        character.intimacyProfile.postIntimacyBehavior
                      ]?.label ?? character.intimacyProfile.postIntimacyBehavior}
                    </Badge>
                  </div>
                  <p className="mt-1.5 text-muted-foreground text-xs leading-relaxed">
                    {character.intimacyProfile.postIntimacyBehaviorReasoning}
                  </p>
                </div>
                <Separator className="border-white/6" />
                <CollapsibleField
                  label="Circumstantial Triggers"
                  value={character.intimacyProfile.circumstantialTriggers}
                />
              </div>
            </Section>
          </div>
        </TabsContent>

        <TabsContent value="scenes">
          <Section
            icon={<Image className="h-4 w-4" />}
            title={`Scene Image Prompts (${scenes.length})`}
          >
            <div className="mb-4 flex items-center gap-2">
              <span className="text-muted-foreground text-xs">Model:</span>
              <Badge className={imageModelMeta.color} variant="outline">
                <Palette className="mr-1 h-3 w-3" />
                {imageModelMeta.label}
              </Badge>
            </div>
            <div className="space-y-6">
              {scenes.map((scene, i) => (
                <div key={scene.sceneName}>
                  {i > 0 && <Separator className="mb-6 border-white/6" />}
                  <h3 className="mb-3 font-semibold text-sm">
                    Scene {i + 1}: {scene.sceneName}
                  </h3>
                  <div className="space-y-4 border-primary/20 border-l-2 pl-4">
                    <Field label="Prompt" mono value={scene.prompt} />
                    {scene.negativePrompt && (
                      <Field
                        label="Negative Prompt"
                        mono
                        value={scene.negativePrompt}
                      />
                    )}
                  </div>
                </div>
              ))}
            </div>
          </Section>
        </TabsContent>
      </Tabs>
    </div>
  )
}
