import { Maximize2, Minimize2, Minus, Plus, Settings, Sparkles, X } from "lucide-react";
import { motion } from "motion/react";
import { type CSSProperties, useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { useRoute } from "@/lib/router";
import { cn } from "@/lib/utils";

const isMac = window.api.window.platform === "darwin";

const DRAG_STYLE = { WebkitAppRegion: "drag" } as unknown as CSSProperties;
const NO_DRAG_STYLE = { WebkitAppRegion: "no-drag" } as unknown as CSSProperties;

type NavKey = "gallery" | "create" | "settings";

export function NavHeader() {
  const route = useRoute();
  const activeKey: NavKey | null =
    route.name === "gallery"
      ? "gallery"
      : route.name === "create"
        ? "create"
        : route.name === "settings"
          ? "settings"
          : null;

  return (
    <header
      className="sticky top-0 z-50 border-white/6 border-b bg-background/60 backdrop-blur-2xl"
      style={DRAG_STYLE}
    >
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent" />
      <div
        className={cn(
          "mx-auto flex h-14 max-w-5xl items-center justify-between px-4",
          isMac && "pl-20"
        )}
      >
        <motion.a
          className="flex items-center gap-2.5"
          href="#/"
          style={NO_DRAG_STYLE}
          transition={{ type: "spring", stiffness: 400, damping: 22 }}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          <motion.div
            className="glow-sm flex h-7 w-7 items-center justify-center rounded-lg bg-primary/15"
            transition={{ type: "spring", stiffness: 400, damping: 22 }}
            whileHover={{ rotate: -8 }}
          >
            <Sparkles className="h-3.5 w-3.5 text-primary" />
          </motion.div>
          <span className="font-semibold text-sm tracking-tight">AI Character Creator</span>
        </motion.a>
        <div className="flex items-center">
          <nav
            className="relative flex items-center gap-1"
            style={NO_DRAG_STYLE}
          >
            <NavItem active={activeKey === "gallery"} href="#/" navKey="gallery">
              Gallery
            </NavItem>
            <NavItem active={activeKey === "create"} href="#/create" highlight navKey="create">
              <Plus className="mr-1 h-3.5 w-3.5" />
              Create
            </NavItem>
            <a href="#/settings">
              <Button
                className={cn(
                  "text-muted-foreground transition-colors",
                  activeKey === "settings" && "bg-accent text-accent-foreground"
                )}
                size="icon-sm"
                variant="ghost"
              >
                <Settings className="h-3.5 w-3.5" />
                <span className="sr-only">Settings</span>
              </Button>
            </a>
          </nav>
          {!isMac && <WindowControls />}
        </div>
      </div>
    </header>
  );
}

interface NavItemProps {
  href: string;
  navKey: NavKey;
  active: boolean;
  highlight?: boolean;
  children: React.ReactNode;
}

function NavItem({ href, active, highlight, children }: NavItemProps) {
  return (
    <a className="relative" href={href}>
      <Button
        className={cn(
          "relative z-10",
          active
            ? highlight
              ? "glow-sm"
              : "text-accent-foreground"
            : "text-muted-foreground"
        )}
        size="sm"
        variant={active && highlight ? "default" : "ghost"}
      >
        {children}
      </Button>
      {active && !highlight && (
        <motion.div
          className="-z-0 absolute inset-0 rounded-md bg-accent"
          layoutId="nav-active-pill"
          transition={{ type: "spring", stiffness: 420, damping: 32 }}
        />
      )}
    </a>
  );
}

function WindowControls() {
  const [maximized, setMaximized] = useState(false);

  useEffect(() => {
    void window.api.window.isMaximized().then(setMaximized);
    const off = window.api.window.onMaximizeChange(setMaximized);
    return () => off();
  }, []);

  return (
    <div className="ml-3 flex items-center" style={NO_DRAG_STYLE}>
      <button
        aria-label="Minimize"
        className="flex h-9 w-11 items-center justify-center text-muted-foreground transition hover:bg-white/6 hover:text-foreground"
        onClick={() => void window.api.window.minimize()}
        type="button"
      >
        <Minus className="h-3.5 w-3.5" />
      </button>
      <button
        aria-label={maximized ? "Restore" : "Maximize"}
        className="flex h-9 w-11 items-center justify-center text-muted-foreground transition hover:bg-white/6 hover:text-foreground"
        onClick={async () => {
          const next = await window.api.window.toggleMaximize();
          setMaximized(next.maximized);
        }}
        type="button"
      >
        {maximized ? <Minimize2 className="h-3 w-3" /> : <Maximize2 className="h-3 w-3" />}
      </button>
      <button
        aria-label="Close"
        className="flex h-9 w-11 items-center justify-center text-muted-foreground transition hover:bg-red-500/80 hover:text-white"
        onClick={() => void window.api.window.close()}
        type="button"
      >
        <X className="h-3.5 w-3.5" />
      </button>
    </div>
  );
}
